export declare abstract class Template {
    abstract format(params?: any): string;
}
