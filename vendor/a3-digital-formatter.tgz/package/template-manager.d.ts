import { Template } from './template.js';
export declare class TemplateManager {
    private static _loaded;
    private static _formatter;
    private static _dollarFormatter;
    constructor();
    createTemplate(template: string): Template;
    isParamProvided(param: any): boolean;
    private validateDatesInFITimezone;
    private validateDatesInFITimezoneIgnoringTime;
    private validateMultipleDatesInFITimezone;
    private validateMultipleDatesInFITimezoneIgnoringTime;
    private validateNumericArguments;
}
