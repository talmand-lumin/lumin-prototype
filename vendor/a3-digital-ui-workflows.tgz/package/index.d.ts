import * as i0 from '@angular/core';
import { TemplateRef, EventEmitter, OnChanges, SimpleChanges, OnInit, DoCheck, ElementRef, AfterViewInit, ChangeDetectorRef, NgZone, Component, Injector } from '@angular/core';
import * as i28 from '@angular/forms';
import { FormGroup, UntypedFormGroup, UntypedFormBuilder } from '@angular/forms';
import { Params, Router } from '@angular/router';
import * as i30 from '@a3-digital/ui-core';
import { BaseTextComponent, TextService, ModalService, Action, BadgeModel, ButtonCardItem, WindowService, BadgeTheme, ChipListItem, NotificationTheme, GridItem, ContainerTheme, PipedDetail, HtmlAttributeState, ButtonMenuOption, IconComponent, PageActionItem, BaseDestroyComponent } from '@a3-digital/ui-core';
import * as i31 from '@a3-digital/ui-forms';
import { FormRendererRow, RadioButtonOption, TextAreaIconButton, WorkflowInputComponent, WorkflowInputOption, PickerOption, MultiSelectPickerOption, SearchInputComponent, BaseTemplateData, TemplateGroup, DropdownAction, FormRendererComponent, TextAreaField, AccountTemplateData, FormRendererSelectionEvent } from '@a3-digital/ui-forms';
import { LuminAiAssistantNavigationItem } from '@a3-digital/lumin-ai-interface';
import * as rxjs from 'rxjs';
import { Observable } from 'rxjs';
import { DateProvider, Holiday } from '@a3-digital/date-utils';
import { ValidationResult } from '@a3-digital/validation';
import * as i26 from '@angular/common';
import * as i27 from '@angular/cdk/drag-drop';
import * as i29 from '@ng-bootstrap/ng-bootstrap';

declare class AddressVerificationModalComponent extends BaseTextComponent {
    private modalService;
    protected textService: TextService;
    addressModal: TemplateRef<any>;
    /**
    * Optional. Information to display near the top of the modal.
    * Defaults to: 'The United States Postal Service suggests using the Recommended Address below.'
    **/
    infoText: string;
    /**
    * Optional. Set to true to prevent the modal from closing when the scrim (backdrop) is clicked or when
    * the ESC key is pressed. The modal can only be dismissed via its close, cancel, or submit
    * buttons, or programmatically (e.g. modalService.dismissAll()).
    **/
    lockScrim: boolean;
    /**
    * Emits the selected address value.
    **/
    primaryButtonClick: EventEmitter<string | number>;
    formRows: FormRendererRow[];
    constructor(modalService: ModalService, textService: TextService);
    /**
    * Opens the modal. `recommended` is the USPS-corrected address and is pre-selected on open.
    * `entered` is the address the user originally typed. The option labels are owned by this
    * component — only `value` and `subtextLines` need to be set by the caller.
    **/
    showAddressOptions(recommended: RadioButtonOption, entered: RadioButtonOption): void;
    selectAddress(form: FormGroup): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<AddressVerificationModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AddressVerificationModalComponent, "ui-workflows-address-verification-modal", never, { "infoText": { "alias": "infoText"; "required": false; }; "lockScrim": { "alias": "lockScrim"; "required": false; }; }, { "primaryButtonClick": "primaryButtonClick"; }, never, never, false, never>;
}

declare class ConfirmationModalEvent {
    confirm: boolean;
    dontShowAgain: boolean;
    constructor(confirm?: boolean, dontShowAgain?: boolean);
}

declare class ConfirmationModalComponent extends BaseTextComponent {
    private modalService;
    protected textService: TextService;
    confirmationModal: TemplateRef<any>;
    /**
    * Optional modal title. Default is "Are you sure?"
    **/
    title: string;
    /**
    * Required. The message inside the modal body.
    **/
    message: string;
    /**
    * Optional. Extra message inside the modal body.
    **/
    additionalMessage: string;
    /**
    * Optional. Bullet list label that displays under the messages if bullet list items are provided.
    **/
    bulletListLabel: string;
    /**
    * Optional. CSS classes to apply to the bullet list label.
    **/
    bulletListLabelClasses: string;
    /**
    * Optional. Bullet list items that displays under the messages
    **/
    bulletListItems: string[];
    /**
    * Optional. Whether or not the "Don't show again" checkbox is displayed
    **/
    showDontShowAgainCheckbox: boolean;
    /**
    * Optional. Whether or not the primary button should dismiss all modals.
    **/
    primaryButtonDismissesAllModals: boolean;
    /**
    * Optional primary button text. Default is "Accept and Continue"
    **/
    primaryButtonText: string;
    /**
    * Optional secondary button text. Default is "Cancel"
    **/
    secondaryButtonText: string;
    /**
    * Set to true to prevent the modal from closing when the scrim (backdrop) is clicked or when
    * the ESC key is pressed. The modal can only be dismissed via its close, cancel, or submit
    * buttons, or programmatically (e.g. modalService.dismissAll()).
    **/
    lockScrim: boolean;
    /**
    * Emits when Cancel or Confirm buttons are clicked. Includes button and checkbox values.
    **/
    clicked: EventEmitter<ConfirmationModalEvent>;
    modalTitle: string;
    confirmButtonText: string;
    cancelButtonText: string;
    private valueEmitted;
    dontShowAgain: boolean;
    constructor(modalService: ModalService, textService: TextService);
    show(): void;
    modalClosed(): void;
    closeModal(confirmed: boolean): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfirmationModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfirmationModalComponent, "ui-workflows-confirmation-modal", never, { "title": { "alias": "title"; "required": false; }; "message": { "alias": "message"; "required": false; }; "additionalMessage": { "alias": "additionalMessage"; "required": false; }; "bulletListLabel": { "alias": "bulletListLabel"; "required": false; }; "bulletListLabelClasses": { "alias": "bulletListLabelClasses"; "required": false; }; "bulletListItems": { "alias": "bulletListItems"; "required": false; }; "showDontShowAgainCheckbox": { "alias": "showDontShowAgainCheckbox"; "required": false; }; "primaryButtonDismissesAllModals": { "alias": "primaryButtonDismissesAllModals"; "required": false; }; "primaryButtonText": { "alias": "primaryButtonText"; "required": false; }; "secondaryButtonText": { "alias": "secondaryButtonText"; "required": false; }; "lockScrim": { "alias": "lockScrim"; "required": false; }; }, { "clicked": "clicked"; }, never, never, false, never>;
}

declare class EditLabelValueModalComponent extends BaseTextComponent implements OnChanges {
    private modalService;
    protected textService: TextService;
    editModal: TemplateRef<any>;
    private formRenderer;
    private unsavedChangesModal;
    /**
    * The label for the label-value. Also used to generate the modal title and form label.
    **/
    label: string;
    /**
    * The value for the label-value. If the value is updated successfully, this input must be updated
    * with the new value.
    **/
    value: string;
    /**
    * Optional error message to display. Default value is "Required"
    **/
    errorMessage: string;
    /**
    * The max length of the form field.
    **/
    maxLength: number;
    /**
    * Optional regex to enforce for validation.
    **/
    validationRegex: string;
    /**
    * Optional loading spinner to help long running API calls.
    **/
    showSpinner: boolean;
    /**
    * Show the form field as a text area.
    **/
    showTextArea: boolean;
    /**
    * By default, a value is required in the form field.
    * If this is set to true, the form field can be empty.
    **/
    valueIsOptional: boolean;
    /**
    * Optional label for the edit link, rendered when the value is an empty string.
    * Default is "Edit".
    **/
    editLinkText: string;
    /**
    * Optional text override for the submit (primary) button. Defaults to "Update"
    **/
    submitButtonText: string;
    /**
    * Allows for a custom e2e prefix. Default is "edit-label-value"
    **/
    e2e: string;
    /**
    * If enabled, edit button is right aligned.
    **/
    rightAlignEditButton: boolean;
    /**
    * Class(es) to apply to outer container of the label-value for spacing.
    **/
    elementClass: string;
    /**
    * If enabled, shows a border at the bottom of the label-value.
    **/
    borderBottom: boolean;
    /**
    * Set to true to prevent the modal from closing when the scrim (backdrop) is clicked or when
    * the ESC key is pressed. The modal can only be dismissed via its close (X), cancel, or submit
    * buttons, or programmatically (e.g. modalService.dismissAll()).
    *
    * Use this for modals where closing mid-flow is not allowed (e.g. a required step that must complete).
    * For warning about unsaved form changes, use confirmUnsavedChanges instead.
    * Avoid setting both lockScrim and confirmUnsavedChanges to true — they have overlapping but
    * subtly different behavior and are not designed to be used together.
    **/
    lockScrim: boolean;
    /**
    * Set to true to show an unsaved changes confirmation when the user attempts to close the modal
    * via the close (X) button, scrim click, ESC key, or cancel button, and the form is dirty.
    * If the form has not been modified, the modal closes normally without a confirmation.
    *
    * Use this for form modals where the user could lose unsaved work.
    * For modals where closing mid-flow must be completely prevented, use lockScrim instead.
    * Avoid setting both confirmUnsavedChanges and lockScrim to true — they are not designed to be used together.
    **/
    confirmUnsavedChanges: boolean;
    readonly checkUnsavedChangesHandler: any;
    /**
    * Emits if the user cancels the action (with the "Cancel" button or by closing the modal)
    **/
    cancelled: EventEmitter<void>;
    /**
    * Emits the new value if it is valid, and different from the original value.
    **/
    updated: EventEmitter<string>;
    formRows: FormRendererRow[];
    modalTitle: string;
    iconRight: string;
    actualValue: string;
    valueIsLink: boolean;
    constructor(modalService: ModalService, textService: TextService);
    ngOnChanges(changes: SimpleChanges): void;
    editClicked(): void;
    private createForm;
    private launchModal;
    submitForm(): void;
    cancelEdit(): Promise<void>;
    private checkUnsavedChanges;
    private closeModal;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<EditLabelValueModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EditLabelValueModalComponent, "ui-workflows-edit-label-value-modal", never, { "label": { "alias": "label"; "required": false; }; "value": { "alias": "value"; "required": false; }; "errorMessage": { "alias": "errorMessage"; "required": false; }; "maxLength": { "alias": "maxLength"; "required": false; }; "validationRegex": { "alias": "validationRegex"; "required": false; }; "showSpinner": { "alias": "showSpinner"; "required": false; }; "showTextArea": { "alias": "showTextArea"; "required": false; }; "valueIsOptional": { "alias": "valueIsOptional"; "required": false; }; "editLinkText": { "alias": "editLinkText"; "required": false; }; "submitButtonText": { "alias": "submitButtonText"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; "rightAlignEditButton": { "alias": "rightAlignEditButton"; "required": false; }; "elementClass": { "alias": "elementClass"; "required": false; }; "borderBottom": { "alias": "borderBottom"; "required": false; }; "lockScrim": { "alias": "lockScrim"; "required": false; }; "confirmUnsavedChanges": { "alias": "confirmUnsavedChanges"; "required": false; }; }, { "cancelled": "cancelled"; "updated": "updated"; }, never, never, false, never>;
}

declare class ReasonModalEvent {
    submitted: boolean;
    reason: string;
    constructor(submitted?: boolean, reason?: string);
}

declare class ReasonModalComponent extends BaseTextComponent {
    private modalService;
    protected textService: TextService;
    reasonModal: TemplateRef<any>;
    private formRenderer;
    private unsavedChangesModal;
    /**
    * Optional modal title. Default is "Provide Reason"
    **/
    title: string;
    /**
    * Optional description text.
    **/
    description: string;
    /**
    * Optional label for the textarea field. Default is "Please provide a reason:"
    **/
    label: string;
    /**
    * Optional. Max number of characters in the textarea. Default is 500.
    **/
    reasonMaxLength: number;
    /**
    * Optional. Whether or not the primary button should dismiss all modals.
    **/
    primaryButtonDismissesAllModals: boolean;
    /**
    * Optional primary button text. Default is "Submit"
    **/
    primaryButtonText: string;
    /**
    * Optional secondary button text. Default is "Cancel"
    **/
    secondaryButtonText: string;
    /**
    * Optional. Whether or not submitting a reason in the textarea is required. Defaults to true
    **/
    isRequired: boolean;
    /**
    * Set to true to prevent the modal from closing when the scrim (backdrop) is clicked or when
    * the ESC key is pressed. The modal can only be dismissed via its close (X), cancel, or submit
    * buttons, or programmatically (e.g. modalService.dismissAll()).
    *
    * Use this for modals where closing mid-flow is not allowed (e.g. a required step that must complete).
    * For warning about unsaved form changes, use confirmUnsavedChanges instead.
    * Avoid setting both lockScrim and confirmUnsavedChanges to true — they have overlapping but
    * subtly different behavior and are not designed to be used together.
    **/
    lockScrim: boolean;
    /**
    * Set to true to show an unsaved changes confirmation when the user attempts to close the modal
    * via the close (X) button, scrim click, ESC key, or cancel button, and the form is dirty.
    * If the form has not been modified, the modal closes normally without a confirmation.
    *
    * Use this for form modals where the user could lose unsaved work.
    * For modals where closing mid-flow must be completely prevented, use lockScrim instead.
    * Avoid setting both confirmUnsavedChanges and lockScrim to true — they are not designed to be used together.
    **/
    confirmUnsavedChanges: boolean;
    readonly checkUnsavedChangesHandler: any;
    /**
    * Emits when Cancel or Confirm buttons are clicked. Includes textarea value.
    **/
    clicked: EventEmitter<ReasonModalEvent>;
    private valueEmitted;
    modalTitle: string;
    textareaLabel: string;
    submitButtonText: string;
    cancelButtonText: string;
    formRows: FormRendererRow[];
    constructor(modalService: ModalService, textService: TextService);
    show(): void;
    modalClosed(): void;
    private checkUnsavedChanges;
    onButtonClick(submitting: boolean, form?: FormGroup): Promise<void>;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<ReasonModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ReasonModalComponent, "ui-workflows-reason-modal", never, { "title": { "alias": "title"; "required": false; }; "description": { "alias": "description"; "required": false; }; "label": { "alias": "label"; "required": false; }; "reasonMaxLength": { "alias": "reasonMaxLength"; "required": false; }; "primaryButtonDismissesAllModals": { "alias": "primaryButtonDismissesAllModals"; "required": false; }; "primaryButtonText": { "alias": "primaryButtonText"; "required": false; }; "secondaryButtonText": { "alias": "secondaryButtonText"; "required": false; }; "isRequired": { "alias": "isRequired"; "required": false; }; "lockScrim": { "alias": "lockScrim"; "required": false; }; "confirmUnsavedChanges": { "alias": "confirmUnsavedChanges"; "required": false; }; }, { "clicked": "clicked"; }, never, never, false, never>;
}

declare enum ChatMessageActionType {
    REPLY = "REPLY",
    NAVIGATION = "NAVIGATION"
}
declare enum ChatMessageReplyActionRole {
    CONFIRM = "CONFIRM",
    CANCEL = "CANCEL"
}
declare class ChatMessageAction implements Action {
    text: string;
    type: ChatMessageActionType;
    role?: ChatMessageReplyActionRole;
    url?: string;
    clicked?: boolean;
    e2e?: string;
    action?: (item?: any) => void;
    urlQueryParams?: Params;
    externalUrlNewTab?: boolean;
    icon?: string;
}

declare enum ChatMessageDirection {
    INCOMING = "INCOMING",
    OUTGOING = "OUTGOING"
}

declare enum ChatMessageSenderType {
    ASSISTANT = "ASSISTANT",
    MEMBER = "MEMBER",
    ADMIN = "ADMIN",
    SYSTEM = "SYSTEM"
}

declare class ChatMessage {
    message: string;
    messageId?: string;
    senderName: string;
    senderType: ChatMessageSenderType;
    direction: ChatMessageDirection;
    navMatches: LuminAiAssistantNavigationItem[];
    actions: ChatMessageAction[];
    hasClickedAction: boolean;
    sendActionErrorMessage: string;
    sentAt: Date;
    timestampText?: string;
    get isFromMember(): boolean;
    get isFromAssistant(): boolean;
    get isFromAdmin(): boolean;
    get isFromSystem(): boolean;
    get isOutgoing(): boolean;
    get isIncoming(): boolean;
    static iconFor(message: ChatMessage): string;
    static cssClassFor(message: ChatMessage, memberCssClass: string): string;
    static fromObject(data: any): ChatMessage;
}

declare class ChatSession {
    sessionId: string;
    title: string;
    startedAt: Date;
    messages: ChatMessage[];
    static fromObject(data: any): ChatSession;
}

declare enum ChatWindowMode {
    CHAT = "CHAT",
    HISTORY_LIST = "HISTORY_LIST",
    HISTORY_DETAIL = "HISTORY_DETAIL"
}

declare class ChatWindowComponent extends BaseTextComponent implements OnInit, OnChanges, DoCheck {
    private formBuilder;
    protected textService: TextService;
    private windowService;
    private router;
    chatBody: ElementRef;
    confirmationModal: ConfirmationModalComponent;
    /**
    * Optional title for the chat window.
    **/
    title: string;
    /**
    * Optional. Badge shown in the header.
    **/
    headerBadge: BadgeModel;
    /**
    * Optional. The message to show if loading the chat fails.
    **/
    failedToLoadMessage: string;
    /**
    * Optional. The message to show if sending an action fails.
    **/
    failedToSendActionMessage: string;
    /**
    * Optional. Whether or not the chat window is visible.
    **/
    isVisible: boolean;
    /**
    * Optional. Whether or not to anchor the chat button to the bottom right of the screen.
    **/
    anchorChatButton: boolean;
    /**
    * Optional. Whether or not the chat component is loading.
    **/
    loading: boolean;
    /**
    * Optional. Whether or not a response is pending from the chat service.
    **/
    pendingResponse: boolean;
    /**
    * Optional. The messages to show in the chat.
    **/
    messages: ChatMessage[];
    /**
    * Optional. The unread message count to show as a badge on the floating chat button while minimized.
    * A value of 0 (the default) hides the badge. Values over 99 display as 99.
    **/
    unreadCount: number;
    /**
    * Optional. Previous chat sessions to show on the Chat History screen.
    **/
    chatHistorySessions: ChatSession[];
    /**
    * Emits the attach file event when the attach file button is clicked.
    **/
    attachFileClicked: EventEmitter<string>;
    /**
    * Emits when the chat window is closed.
    **/
    closed: EventEmitter<void>;
    /**
    * Emits the search value when the Search button is clicked.
    **/
    searched: EventEmitter<string>;
    /**
    * Emits the voice input event when the voice input button is clicked.
    **/
    voiceClicked: EventEmitter<string>;
    /**
    * Emits the action object when a chat message action is clicked.
    **/
    action: EventEmitter<ChatMessageAction>;
    chatIconButtons: TextAreaIconButton[];
    chatButtonAriaLabel: string;
    chatTitle: string;
    dragPosition: {
        x: number;
        y: number;
    };
    isMinimized: boolean;
    isMobile: boolean;
    mode: ChatWindowMode;
    selectedHistorySession: ChatSession | null;
    protected ChatWindowMode: typeof ChatWindowMode;
    get unreadCountDisplay(): string;
    get historyButtonCardItems(): ButtonCardItem[];
    readonly searchFormId: string;
    searchForm: UntypedFormGroup | null;
    clickedChatMessageAction: ChatMessageAction | null;
    private readonly attachFileIcon;
    private readonly micIcon;
    private readonly sendMessageIcon;
    private lastMessageContent;
    private lastTrackedMessage;
    constructor(formBuilder: UntypedFormBuilder, textService: TextService, windowService: WindowService, router: Router);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngDoCheck(): void;
    toggleChatWindow(): void;
    openChatHistory(): void;
    selectChatHistorySession(sessionId: string): void;
    backToChat(): void;
    backToChatHistory(): void;
    submitSearch(): void;
    onIconButtonClick(button: TextAreaIconButton): void;
    onChatMessageActionClick(message: ChatMessage, action: ChatMessageAction): void;
    protected messageIcon(message: ChatMessage): string;
    protected messageLabel(message: ChatMessage): string;
    protected messageCssClass(message: ChatMessage): string;
    closeChatWindow(): void;
    onConfirmationModalClick(event: ConfirmationModalEvent): void;
    private resetChatWindowPosition;
    private focusSearchField;
    private scrollFooterIntoView;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChatWindowComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChatWindowComponent, "ui-workflows-chat-window", never, { "title": { "alias": "title"; "required": false; }; "headerBadge": { "alias": "headerBadge"; "required": false; }; "failedToLoadMessage": { "alias": "failedToLoadMessage"; "required": false; }; "failedToSendActionMessage": { "alias": "failedToSendActionMessage"; "required": false; }; "isVisible": { "alias": "isVisible"; "required": false; }; "anchorChatButton": { "alias": "anchorChatButton"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; "pendingResponse": { "alias": "pendingResponse"; "required": false; }; "messages": { "alias": "messages"; "required": false; }; "unreadCount": { "alias": "unreadCount"; "required": false; }; "chatHistorySessions": { "alias": "chatHistorySessions"; "required": false; }; }, { "attachFileClicked": "attachFileClicked"; "closed": "closed"; "searched": "searched"; "voiceClicked": "voiceClicked"; "action": "action"; }, never, never, false, never>;
}

interface ChatMessageActionClickEvent {
    message: ChatMessage;
    action: ChatMessageAction;
}
declare class ChatMessageBodyComponent {
    /**
    * Required. The message to render.
    **/
    message: ChatMessage;
    /**
    * Optional. Whether or not a response is pending from the chat service; disables action buttons.
    **/
    pendingResponse: boolean;
    /**
    * Optional. The action most recently clicked, used to show a spinner on the matching button.
    **/
    clickedChatMessageAction: ChatMessageAction | null;
    /**
    * Optional. Label shown before a single navigation match link.
    **/
    searchLinkMessage: string;
    /**
    * Optional. Label shown above multiple navigation match links.
    **/
    searchLinksMessage: string;
    /**
    * Emits the message and action when a reply/navigation action button is clicked.
    **/
    actionClicked: EventEmitter<ChatMessageActionClickEvent>;
    protected ChatMessageActionType: typeof ChatMessageActionType;
    protected ChatMessageReplyActionRole: typeof ChatMessageReplyActionRole;
    onActionClick(action: ChatMessageAction): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChatMessageBodyComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChatMessageBodyComponent, "ui-workflows-chat-message-body", never, { "message": { "alias": "message"; "required": false; }; "pendingResponse": { "alias": "pendingResponse"; "required": false; }; "clickedChatMessageAction": { "alias": "clickedChatMessageAction"; "required": false; }; "searchLinkMessage": { "alias": "searchLinkMessage"; "required": false; }; "searchLinksMessage": { "alias": "searchLinksMessage"; "required": false; }; }, { "actionClicked": "actionClicked"; }, never, never, false, never>;
}

declare class ChatMessageComponent {
    /**
    * Required. The message to render. Positioning (left/right) is driven by `message.direction`,
    * not by `senderType` - callers decide incoming/outgoing based on their own persona.
    **/
    message: ChatMessage;
    /**
    * Avatar icon shown in the message header. Ignored for SYSTEM messages.
    **/
    icon: string;
    /**
    * Label shown next to the avatar in the message header. Ignored for SYSTEM messages.
    **/
    label: string;
    /**
    * Bubble background/text CSS class(es), e.g. 'assistant-message'. Ignored for SYSTEM messages.
    **/
    cssClass: string | string[];
    /**
    * Optional. Whether or not a response is pending from the chat service; disables action buttons.
    **/
    pendingResponse: boolean;
    /**
    * Optional. The action most recently clicked, used to show a spinner on the matching button.
    **/
    clickedChatMessageAction: ChatMessageAction | null;
    /**
    * Optional. Label shown before a single navigation match link.
    **/
    searchLinkMessage: string;
    /**
    * Optional. Label shown above multiple navigation match links.
    **/
    searchLinksMessage: string;
    /**
    * Emits the message and action when a reply/navigation action button is clicked.
    **/
    actionClicked: EventEmitter<ChatMessageActionClickEvent>;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChatMessageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChatMessageComponent, "ui-workflows-chat-message", never, { "message": { "alias": "message"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "label": { "alias": "label"; "required": false; }; "cssClass": { "alias": "cssClass"; "required": false; }; "pendingResponse": { "alias": "pendingResponse"; "required": false; }; "clickedChatMessageAction": { "alias": "clickedChatMessageAction"; "required": false; }; "searchLinkMessage": { "alias": "searchLinkMessage"; "required": false; }; "searchLinksMessage": { "alias": "searchLinksMessage"; "required": false; }; }, { "actionClicked": "actionClicked"; }, never, never, false, never>;
}

declare class ChatPageAction implements Action {
    text: string;
    icon?: string;
    e2e?: string;
}

declare class ChatPageComponent extends BaseTextComponent implements OnInit, OnChanges, DoCheck {
    private formBuilder;
    protected textService: TextService;
    private router;
    chatBody: ElementRef;
    /**
    * Required. Icon name shown in the header (e.g. 'svg_support_hub').
    **/
    headerIcon: string;
    /**
    * Required. Title shown in the header.
    **/
    headerTitle: string;
    /**
    * Required. Subtitle shown below the title.
    **/
    headerSubtitle: string;
    /**
    * Required. Badge shown in the header (e.g. the user name).
    **/
    headerBadge: BadgeModel;
    /**
    * Optional. Background class applied behind the header icon.
    **/
    headerIconBackgroundClass: string;
    /**
    * Optional. Neutral action buttons shown in the top-right. Only the first 3 are rendered.
    **/
    headerActions: ChatPageAction[];
    /**
    * Optional title for the chat window.
    **/
    title: string;
    /**
    * Optional. The message to show if loading the chat fails.
    **/
    failedToLoadMessage: string;
    /**
    * Optional. The message to show if sending an action fails.
    **/
    failedToSendActionMessage: string;
    /**
    * Optional. Whether or not the chat window is visible.
    **/
    isVisible: boolean;
    /**
    * Optional. Whether or not the chat component is loading.
    **/
    loading: boolean;
    /**
    * Optional. Whether or not a response is pending from the chat service.
    **/
    pendingResponse: boolean;
    /**
    * Optional. The messages to show in the chat.
    **/
    messages: ChatMessage[];
    /**
    * Optional. Background color applied to member message bubbles.
    **/
    memberBubbleBackgroundClass: string;
    /**
    * Optional. Text color applied to member message bubbles.
    **/
    memberBubbleTextClass: string;
    /**
    * Optional. Whether or not to hide the message input area at the bottom of the chat.
    * Set to true for read-only chats, such as a closed or ended conversation.
    **/
    hideMessageInput: boolean;
    /**
    * Emits the action when one of the header action buttons is clicked.
    **/
    headerActionClicked: EventEmitter<ChatPageAction>;
    /**
    * Emits the attach file event when the attach file button is clicked.
    **/
    attachFileClicked: EventEmitter<string>;
    /**
    * Emits the search value when the Search button is clicked.
    **/
    searched: EventEmitter<string>;
    /**
    * Emits the voice input event when the voice input button is clicked.
    **/
    voiceClicked: EventEmitter<string>;
    /**
    * Emits the action object when a chat message action is clicked.
    **/
    chatMessageActionClicked: EventEmitter<ChatMessageAction>;
    chatIconButtons: TextAreaIconButton[];
    chatTitle: string;
    readonly searchFormId: string;
    searchForm: UntypedFormGroup | null;
    clickedChatMessageAction: ChatMessageAction | null;
    private readonly attachFileIcon;
    private readonly micIcon;
    private readonly sendMessageIcon;
    private lastMessageContent;
    lastTrackedMessage: ChatMessage | null;
    /** The rendered actions, capped at 3. */
    get visibleHeaderActions(): ChatPageAction[];
    constructor(formBuilder: UntypedFormBuilder, textService: TextService, router: Router);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngDoCheck(): void;
    submitSearch(): void;
    onHeaderActionClick(action: ChatPageAction): void;
    onIconButtonClick(button: TextAreaIconButton): void;
    protected messageIcon(message: ChatMessage): string;
    protected messageLabel(message: ChatMessage): string;
    protected messageCssClass(message: ChatMessage): string;
    onChatMessageActionClick(message: ChatMessage, action: ChatMessageAction): void;
    private focusSearchField;
    private scrollFooterIntoView;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChatPageComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChatPageComponent, "ui-workflows-chat-page", never, { "headerIcon": { "alias": "headerIcon"; "required": false; }; "headerTitle": { "alias": "headerTitle"; "required": false; }; "headerSubtitle": { "alias": "headerSubtitle"; "required": false; }; "headerBadge": { "alias": "headerBadge"; "required": false; }; "headerIconBackgroundClass": { "alias": "headerIconBackgroundClass"; "required": false; }; "headerActions": { "alias": "headerActions"; "required": false; }; "title": { "alias": "title"; "required": false; }; "failedToLoadMessage": { "alias": "failedToLoadMessage"; "required": false; }; "failedToSendActionMessage": { "alias": "failedToSendActionMessage"; "required": false; }; "isVisible": { "alias": "isVisible"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; "pendingResponse": { "alias": "pendingResponse"; "required": false; }; "messages": { "alias": "messages"; "required": false; }; "memberBubbleBackgroundClass": { "alias": "memberBubbleBackgroundClass"; "required": false; }; "memberBubbleTextClass": { "alias": "memberBubbleTextClass"; "required": false; }; "hideMessageInput": { "alias": "hideMessageInput"; "required": false; }; }, { "headerActionClicked": "headerActionClicked"; "attachFileClicked": "attachFileClicked"; "searched": "searched"; "voiceClicked": "voiceClicked"; "chatMessageActionClicked": "chatMessageActionClicked"; }, never, never, false, never>;
}

declare class BulkActionEvent {
    eventName: string;
    eventData: any;
}

declare class BulkAction {
    action: (dataItem: any) => BulkActionEvent;
    icon?: string;
    text: string;
    visible?: (object: any) => boolean;
}

declare class BulkActionsComponent implements OnChanges {
    actions: BulkAction[];
    clearAllLabel: string;
    emptyLabel: string;
    rowLabel: string;
    allCleared: EventEmitter<void>;
    bulkAction: EventEmitter<BulkAction>;
    BadgeTheme: typeof BadgeTheme;
    hasActions: boolean;
    ngOnChanges(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<BulkActionsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BulkActionsComponent, "ui-workflows-bulk-actions", never, { "actions": { "alias": "actions"; "required": false; }; "clearAllLabel": { "alias": "clearAllLabel"; "required": false; }; "emptyLabel": { "alias": "emptyLabel"; "required": false; }; "rowLabel": { "alias": "rowLabel"; "required": false; }; }, { "allCleared": "allCleared"; "bulkAction": "bulkAction"; }, never, never, false, never>;
}

declare class ChipEditorComponent extends BaseTextComponent implements OnChanges {
    inputComponent: WorkflowInputComponent;
    /**
    * The max length of a single chip
    **/
    maxCharacterLength: number;
    /**
    * The max number of chips allowed
    **/
    maxChipCount: number;
    /**
    * Optional regular expression used to prevent invalid characters from being entered
    **/
    invalidCharactersRegex: string | RegExp;
    /**
    * When enabled, chip messages will be translated to lowercase characters
    **/
    lowercaseOnly: boolean;
    /**
    * The currently applied chips
    **/
    chips: string[];
    /**
    * A custom placeholder for the input. Default is "Add..."
    **/
    placeholder: string;
    /**
    * Required. A label for the input field.
    **/
    label: string;
    /**
    * Can be used to visually hide the label. Label should always be provided, and hidden if undesired
    **/
    hideLabel: boolean;
    /**
    * Optional. A header that renders above the label.
    **/
    header: string;
    /**
    * Set to true to disable buttons.
    **/
    disableButtons: boolean;
    /**
    * Shows a Close button when no changes are detected.
    * Emits the cancelled event.
    **/
    showCloseButton: boolean;
    /**
    * Array of values that a user may select from (but are not required).
    * Presented as a typeahead.
    **/
    options: string[];
    /**
    * Emits the chips when the primary button is clicked
    **/
    updated: EventEmitter<string[]>;
    /**
    * Emits if the user cancels
    **/
    cancelled: EventEmitter<void>;
    /**
    * Emits after a copy-to-clipboard attempt completes. Payload is the success
    * boolean — true when the value reached the clipboard, false on failure.
    * Use this to log audit events at the call site.
    **/
    copied: EventEmitter<boolean>;
    copyValue: string;
    readonly inputId: string;
    readonly labelId: string;
    chipListItems: ChipListItem[];
    canAddMore: boolean;
    hasChanges: boolean;
    instructions: string;
    typeaheadOptions: WorkflowInputOption[];
    NotificationTheme: typeof NotificationTheme;
    constructor(textService: TextService);
    ngOnChanges(changes: SimpleChanges): void;
    onPaste(value: string): void;
    addChip(value: string): void;
    onContainerClick(event: Event): void;
    onActionClick(event: Event): void;
    private closeMenu;
    removeChip(item: ChipListItem): void;
    private setChipList;
    private sanitizeChip;
    private setInstructions;
    private setTypeaheadOptions;
    private get currentValues();
    submit(): void;
    cancel(): void;
    close(): void;
    private reset;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<ChipEditorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ChipEditorComponent, "ui-workflows-chip-editor", never, { "maxCharacterLength": { "alias": "maxCharacterLength"; "required": false; }; "maxChipCount": { "alias": "maxChipCount"; "required": false; }; "invalidCharactersRegex": { "alias": "invalidCharactersRegex"; "required": false; }; "lowercaseOnly": { "alias": "lowercaseOnly"; "required": false; }; "chips": { "alias": "chips"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "label": { "alias": "label"; "required": false; }; "hideLabel": { "alias": "hideLabel"; "required": false; }; "header": { "alias": "header"; "required": false; }; "disableButtons": { "alias": "disableButtons"; "required": false; }; "showCloseButton": { "alias": "showCloseButton"; "required": false; }; "options": { "alias": "options"; "required": false; }; }, { "updated": "updated"; "cancelled": "cancelled"; "copied": "copied"; }, never, never, false, never>;
}

declare abstract class BaseDataCardItem {
    label: string;
    readonly type: 'display' | 'editable' | 'sensitive';
    id: string;
    e2e: string;
    value: string;
    values: string[];
    constructor(label: string, value: string | string[], type: 'display' | 'editable' | 'sensitive');
}

declare class DataCardEditItem extends BaseDataCardItem {
    label: string;
    value: string;
    errorMessage: string;
    maxLength: number;
    submitButtonText: string;
    validationRegex: string;
    showTextArea: boolean;
    valueIsOptional: boolean;
    showSpinner: boolean;
    editLinkText: string;
    updatedValue: string;
    constructor(label: string, value: string);
    persistUpdatedValue(): void;
    static fromObject(data: any): DataCardEditItem;
}

declare class DataCardDisplayItem extends BaseDataCardItem {
    labelIcon: string;
    iconLeft: string;
    iconRight: string;
    iconRightAriaLabel: string;
    iconLeftColorClass: string;
    iconLeftAllowEmojis: boolean;
    tooltipContent: string;
    masked: boolean;
    showCopyToClipboard: boolean;
    valueIsLink: boolean;
    externalUrlNewTab: boolean;
    url: string;
    notificationMessage: string;
    notificationTheme: NotificationTheme;
    notificationIcon: string;
    constructor(label: string, value: string | string[]);
    static fromObject(data: any): DataCardDisplayItem;
}

declare class DataCardSensitiveItem extends BaseDataCardItem {
    maskedValues: string[];
    getUnmaskedValue: () => Observable<string>;
    _inProgress: boolean;
    _failed: boolean;
    _hasUnmaskedValue: boolean;
    constructor(label: string, maskedValue: string, getUnmaskedValue: () => Observable<string>);
    static fromObject(data: any): DataCardSensitiveItem;
}

type DataCardItem = DataCardDisplayItem | DataCardEditItem | DataCardSensitiveItem;

declare class DataCardItemGroup {
    items: DataCardItem[];
    label?: string;
    constructor(items?: DataCardItem[], label?: string);
    static fromObject(data: any): DataCardItemGroup;
}

declare class DataCardComponent extends BaseTextComponent implements OnChanges {
    private textService;
    private windowService;
    /**
    * Optional.
    **/
    header: string;
    /**
    * Optional badges that display to the right of the header text.
    **/
    headerBadges: BadgeModel[];
    /**
    * Items to be rendered.
    **/
    items: DataCardItem[];
    /**
    * Items to be rendered within groupings. Each DataCardItemGroup contains an array of DataCardItem along with an optional group label.
    **/
    itemGroups: DataCardItemGroup[];
    /**
    * Optional. When provided, an action button will be rendered in the bottom left corner of the card.
    **/
    firstActionButtonIcon: string;
    /**
    * Required if "firstActionButtonIcon" is provided. The label for the first action button.
    **/
    firstActionButtonLabel: string;
    /**
    * Optional. The neutral theme for the first action button. Defaults to 'secondary'.
    **/
    firstActionButtonTheme: 'primary' | 'secondary' | 'tertiary';
    /**
    * Optional. When provided, a second action button will be rendered in the bottom left corner of the card.
    **/
    secondActionButtonIcon: string;
    /**
    * Required if "secondActionButtonIcon" is provided. The label for the second action button.
    **/
    secondActionButtonLabel: string;
    /**
    * Optional. The neutral theme for the second action button. Defaults to 'secondary'.
    **/
    secondActionButtonTheme: 'primary' | 'secondary' | 'tertiary';
    /**
    * The theme of the card, which directly corresponds to our standard container classes.
    **/
    theme: 'bordered' | 'bordered-interactive' | 'default' | 'elevated' | 'elevated-interactive' | 'sunken' | 'brand';
    /**
    * Optional. E2E customization.
    **/
    e2e: string;
    /**
    * The number of columns to show on tablet. Max is 4.
    * For example, if this is used inside an enhanced modal, recommended number of columns for tablet is 2.
    **/
    tabletColumns: 1 | 2 | 3 | 4;
    /**
    * The number of columns to show on desktop. Max is 4.
    **/
    desktopColumns: 1 | 2 | 3 | 4;
    /**
    * Adds margin to the bottom, useful when stacking multiple cards.
    **/
    marginBottom: boolean;
    /**
    * If enabled, adds a class to make the card full height of the parent container.
    **/
    fullHeight: boolean;
    /**
    * If enabled, reduces spacing and removes horizontal rules within the Data Card for a more compact appearance.
    **/
    isCompact: boolean;
    /**
    * Emits if the user cancels the edit (with the "Cancel" button or by closing the modal)
    **/
    editCanceled: EventEmitter<DataCardEditItem>;
    /**
    * Emits the item with the updatedValue set.
    **/
    itemEdited: EventEmitter<DataCardEditItem>;
    /**
    * Emits the item when the icon right is clicked.
    **/
    iconRightClicked: EventEmitter<DataCardDisplayItem>;
    /**
    * Emits the item when the link is clicked.
    **/
    linkClicked: EventEmitter<DataCardDisplayItem>;
    /**
    * Emits when the first action button is clicked.
    **/
    firstActionButtonClicked: EventEmitter<void>;
    /**
    * Emits when the second action button is clicked.
    **/
    secondActionButtonClicked: EventEmitter<void>;
    /**
    * Emits after a copy-to-clipboard attempt completes on one of the display
    * items. Payload identifies which item's label was copied and whether the
    * copy succeeded. Use this to log audit events at the call site.
    **/
    copied: EventEmitter<{
        label: string;
        success: boolean;
    }>;
    /**
    * Emits when a user toggles the mask on a masked display item. Payload
    * identifies the item and whether the mask is now on (true) or off/revealed
    * (false). Use this to log audit events at the call site.
    **/
    maskToggleClicked: EventEmitter<{
        item: DataCardDisplayItem;
        maskIsOn: boolean;
    }>;
    hasBadges: boolean;
    containerClasses: string;
    e2ePrefix: string;
    firstRowItemCount: number;
    gridItems: GridItem[];
    groupedGridItems: {
        items: GridItem[];
        label: string;
    }[];
    private isMobile;
    private isTablet;
    constructor(textService: TextService, windowService: WindowService);
    ngOnChanges(changes: SimpleChanges): void;
    private updateFirstRowItemCount;
    editItemCanceled(item: DataCardEditItem): void;
    editItemUpdated(item: DataCardEditItem, newValue: string): void;
    onIconRightClick(item: DataCardDisplayItem): void;
    onLinkClick(item: DataCardDisplayItem): void;
    onFirstActionButtonClick(): void;
    onSecondActionButtonClick(): void;
    onItemCopied(item: DataCardDisplayItem, success: boolean): void;
    onItemMaskToggled(item: DataCardDisplayItem, maskIsOn: boolean): void;
    onSensitiveItemMaskToggle(maskIsOn: boolean, item: DataCardSensitiveItem): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<DataCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DataCardComponent, "ui-workflows-data-card", never, { "header": { "alias": "header"; "required": false; }; "headerBadges": { "alias": "headerBadges"; "required": false; }; "items": { "alias": "items"; "required": false; }; "itemGroups": { "alias": "itemGroups"; "required": false; }; "firstActionButtonIcon": { "alias": "firstActionButtonIcon"; "required": false; }; "firstActionButtonLabel": { "alias": "firstActionButtonLabel"; "required": false; }; "firstActionButtonTheme": { "alias": "firstActionButtonTheme"; "required": false; }; "secondActionButtonIcon": { "alias": "secondActionButtonIcon"; "required": false; }; "secondActionButtonLabel": { "alias": "secondActionButtonLabel"; "required": false; }; "secondActionButtonTheme": { "alias": "secondActionButtonTheme"; "required": false; }; "theme": { "alias": "theme"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; "tabletColumns": { "alias": "tabletColumns"; "required": false; }; "desktopColumns": { "alias": "desktopColumns"; "required": false; }; "marginBottom": { "alias": "marginBottom"; "required": false; }; "fullHeight": { "alias": "fullHeight"; "required": false; }; "isCompact": { "alias": "isCompact"; "required": false; }; }, { "editCanceled": "editCanceled"; "itemEdited": "itemEdited"; "iconRightClicked": "iconRightClicked"; "linkClicked": "linkClicked"; "firstActionButtonClicked": "firstActionButtonClicked"; "secondActionButtonClicked": "secondActionButtonClicked"; "copied": "copied"; "maskToggleClicked": "maskToggleClicked"; }, never, never, false, never>;
}

declare class DataCardModel {
    items: DataCardItem[];
    itemGroups: DataCardItemGroup[];
    header: string;
    headerBadges: BadgeModel[];
    firstActionButtonIcon: string;
    firstActionButtonLabel: string;
    secondActionButtonIcon: string;
    secondActionButtonLabel: string;
    theme: ContainerTheme;
    e2e: string;
    tabletColumns: number;
    desktopColumns: number;
    marginBottom: boolean;
    fullHeight: boolean;
    constructor(items: DataCardItem[], itemGroups?: DataCardItemGroup[]);
    static fromObject(data: any): DataCardModel;
}

declare class ListItem {
    constructor(item?: any);
    originalItem: any;
    e2e: string;
    headerDate: Date;
    headerStaticText: string;
    backgroundClass: string;
    verticalPaddingSize: string;
    checked: boolean;
    locked: boolean;
    showDetails: boolean;
    avatarIcon: string;
    avatarIconColorClass: string;
    avatarBackgroundClass: string;
    avatarImageUrl: string;
    avatarShape: string;
    topLeftText: string;
    topLeftClass: string;
    topLeftIcon: string;
    topLeftBadges: BadgeModel[];
    topLeftScreenReaderText: string;
    e2eTopLeft: string;
    topLeftAdditionalText: string;
    topCenterBadge: BadgeModel;
    topRightText: string | number;
    topRightClass: string;
    topRightIcon: string;
    topRightBadge: BadgeModel;
    topRightScreenReaderText: string;
    e2eTopRight: string;
    bottomLeftText: string;
    bottomLeftHtml: string;
    bottomLeftPipedDetails: PipedDetail[];
    bottomLeftScreenReaderText: string;
    e2eBottomLeft: string;
    bottomRightText: string | number;
    bottomRightPipedDetails: PipedDetail[];
    bottomRightScreenReaderText: string;
    e2eBottomRight: string;
    actionButtonIcon: string;
    actionButtonText: string;
    actionButtonTertiaryTextDisplaysOnMobile: boolean;
    actionButtonTheme: 'secondary' | 'tertiary';
    actionButtonMethod: (item?: any) => void;
}

declare class ListItemHeader {
    headerText: string;
    visible: boolean;
    constructor(headerText: string, visible: boolean);
}

declare class SearchSortFilter {
    label: string;
    icon: string;
    options: PickerOption<string>[] | MultiSelectPickerOption<string>[];
    isMultiSelect?: boolean;
    _activeValue?: number | string;
    _activeValues?: string[];
    _isDateRange?: boolean;
    _isTimeSpan?: boolean;
    _isAmountRange?: boolean;
    _pickerOptions?: PickerOption<string>[] | MultiSelectPickerOption<string>[];
    constructor(label: string, icon?: string);
}

declare class SearchSortFilterComponent extends BaseTextComponent implements OnInit, OnChanges {
    private modalService;
    protected textService: TextService;
    private windowService;
    mobileFiltersModal: TemplateRef<any>;
    /**
    * Optional. Whether or not to automatically set focus within the search input.
    **/
    autoFocusSearchInput: boolean;
    /**
    * Optional text used to override the default placeholder text for the search field.
    **/
    searchFieldPlaceholder: string;
    /**
    * Optional text used to manually set the search field value.
    **/
    searchFieldText: string;
    /**
    * Optional array of PickerOptions that are used to sort the list.
    **/
    sortOptions: PickerOption<string>[];
    /**
    * Optional value of the default sort option.
    **/
    sortOptionDefaultValue: string;
    /**
    * Optional. The available customized filters to show. Each SearchSortFilter must define a list of options.
    **/
    customFilters: SearchSortFilter[];
    /**
    * Optional. Specifies whether to include the standard date filters. Defaults to false.
    **/
    includeDateFilters: boolean;
    /**
    * Optional. If "includeDateFilters" is true, this flag determines whether to use "past" or "future" date filters.
    * Defaults to false ("past" date filters).
    **/
    useFutureDateFilters: boolean;
    /**
    * Optional. Specifies whether to include the standard amount range filter. Defaults to false.
    **/
    includeAmountRangeFilter: boolean;
    /**
    * Optional. Whether or not this component's container <div> should have padding at the top. Defaults to true.
    **/
    paddingTop: boolean;
    /**
    * Optional. Whether or not this component is nested within the List Component. Defaults to false.
    **/
    withinListComponent: boolean;
    /**
    * Optional. Whether or not this component shows a "Select All" checkbox to the left of the search field.
    * Only currently applies if "withinListComponent" is true. Defaults to false.
    **/
    showSelectAllCheckbox: boolean;
    /**
    * Optional. Whether or not the "Select All" checkbox is checked.
    * Only applies if "showSelectAllCheckbox" is true. Defaults to false.
    **/
    selectAllCheckboxChecked: boolean;
    /**
    * Optional. Whether or not the "Select All" checkbox is in the indeterminate state.
    * Only applies if "showSelectAllCheckbox" is true. Defaults to false.
    **/
    selectAllCheckboxIndeterminate: boolean;
    /**
    * Optional. E2E testing - data-e2e attribute attached to the list.
    **/
    e2e: string;
    /**
    * Emits boolean value when the "Select All" checkbox is toggled.
    **/
    allSelected: EventEmitter<boolean>;
    /**
    * Emits search value on change.
    **/
    searched: EventEmitter<string>;
    /**
    * Emits sort value when the sort option is changed.
    **/
    sorted: EventEmitter<string>;
    /**
    * Emits all available filters when a filter value is changed.
    **/
    filtered: EventEmitter<SearchSortFilter[]>;
    /**
    * Emits all available filters and a boolean that specifies whether to refilter when the "Clear All" filters
    * button is clicked. A true value (the default) means that the list should be refiltered.
    **/
    filtersCleared: EventEmitter<{
        filters: SearchSortFilter[];
        refilter: boolean;
    }>;
    HtmlAttributeStateEnum: typeof HtmlAttributeState;
    e2ePrefix: string;
    isMobile: boolean;
    filters: SearchSortFilter[];
    hasActiveFilters: boolean;
    showOptions: boolean;
    sortValue: string;
    dateRangeFutureOptions: PickerOption<string>[];
    dateRangePastOptions: PickerOption<string>[];
    constructor(modalService: ModalService, textService: TextService, windowService: WindowService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    private buildListFilters;
    private addDateRangeFilter;
    private addTimeSpanFilter;
    private addAmountRangeFilter;
    get optionsLabel(): string;
    toggleOptions(): void;
    onSelectAllChange(checked: boolean): void;
    onSearchChange(searchText: string): void;
    onSortChange(value: string): void;
    onFilterValueChange(value: string, filter: SearchSortFilter): void;
    onFilterValuesChange(values: string[], filter: SearchSortFilter): void;
    private emitActiveFilterChange;
    clearAllFilters(refilter?: boolean): void;
    closeModal(): void;
    private setE2EPrefix;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchSortFilterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SearchSortFilterComponent, "ui-workflows-search-sort-filter", never, { "autoFocusSearchInput": { "alias": "autoFocusSearchInput"; "required": false; }; "searchFieldPlaceholder": { "alias": "searchFieldPlaceholder"; "required": false; }; "searchFieldText": { "alias": "searchFieldText"; "required": false; }; "sortOptions": { "alias": "sortOptions"; "required": false; }; "sortOptionDefaultValue": { "alias": "sortOptionDefaultValue"; "required": false; }; "customFilters": { "alias": "customFilters"; "required": false; }; "includeDateFilters": { "alias": "includeDateFilters"; "required": false; }; "useFutureDateFilters": { "alias": "useFutureDateFilters"; "required": false; }; "includeAmountRangeFilter": { "alias": "includeAmountRangeFilter"; "required": false; }; "paddingTop": { "alias": "paddingTop"; "required": false; }; "withinListComponent": { "alias": "withinListComponent"; "required": false; }; "showSelectAllCheckbox": { "alias": "showSelectAllCheckbox"; "required": false; }; "selectAllCheckboxChecked": { "alias": "selectAllCheckboxChecked"; "required": false; }; "selectAllCheckboxIndeterminate": { "alias": "selectAllCheckboxIndeterminate"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; }, { "allSelected": "allSelected"; "searched": "searched"; "sorted": "sorted"; "filtered": "filtered"; "filtersCleared": "filtersCleared"; }, never, never, false, never>;
}

declare class ListComponent extends BaseTextComponent implements OnInit, OnChanges, AfterViewInit {
    private dateProvider;
    private modalService;
    private textService;
    private windowService;
    e2eAttr: string;
    detailsModal: TemplateRef<any>;
    mobileViewAllModal: TemplateRef<any>;
    searchSortFilterComponent: SearchSortFilterComponent;
    /**
    * Required. The array of items (of class ListItem) to render in a list.
    **/
    items: ListItem[];
    /**
    * Specifies the number of list items to display on each "page". When the user clicks the "Show More" button, or scrolls to the lazy loading
    * trigger point, this is the number of additional items that will be displayed. Keep undefined for no pagination.
    **/
    pageSize: number;
    /**
    * Enables scroll-triggered lazy loading. When true, the "Show More" button is hidden and additional items are revealed
    * automatically as the user scrolls toward the end of the list. Defaults to false.
    **/
    lazyLoad: boolean;
    /**
    * If "lazyLoad" is true, this controls how far from the end of the list the trigger to load more items is called.
    * Larger values trigger earlier (more pre-fetch); smaller values trigger closer to the end of the list.
    * The value must be a positive CSS length. Defaults to "200px".
    **/
    lazyLoadTriggerDistance: string;
    /**
    * If "lazyLoad" is true, this displays a loading animation and message at the end of the list when the user scrolls to the trigger point.
    * A parent component can fetch additional items from the backend then set this property to false when the fetch completes. Defaults to false.
    **/
    loading: boolean;
    /**
    * Enable emoji support for icons. Checking for emojis is expensive, so only enable if needed.
    **/
    allowEmojis: boolean;
    /**
    * Enable "thread mode" to:
    *  - allow any list item's drawer to be expanded without automatically collapsing other expanded drawers
    *  - allow mobile details templates to render in a drawer instead of a modal
    *  - slightly changes List Template layout to better suit threaded conversations
    **/
    threadModeEnabled: boolean;
    /**
    * Specifies whether to display a checkbox or toggle to the right of each list item.
    **/
    selectionMode: 'checkbox' | 'toggle' | 'none';
    /**
    * If "selectionMode" is set, this allows for an optional "off" aria-label for accessibility purposes.
    **/
    selectionToggledOffAriaLabel: string;
    /**
    * If "selectionMode" is set, this allows for an optional "on" aria-label for accessibility purposes.
    **/
    selectionToggledOnAriaLabel: string;
    /**
    * Whether or not to hide the content on the right side of each list item on mobile. Used to reduce visual clutter.
    **/
    hideRightContentOnMobile: boolean;
    /**
    * Whether or not the list items should be clickable. If true, the entire row will have a visible hover state
    * and allow emitting "listRowClicked" events. Defaults to false, unless a "detailsTemplate" is specified.
    **/
    clickable: boolean;
    /**
    * If "clickable" is set to true, this controls the icon that shows at the end of the list item on desktop/tablet.
    **/
    clickableIcon: string;
    /**
    * If "clickable" is set to true, this allows setting an optional label to the right of the "clickableIcon" on desktop/tablet.
    **/
    clickableLabel: string;
    /**
    * Optional text to show as a header at the top of the list.
    **/
    header: string;
    /**
    * Specifies whether the header should stick to the top of the page when scrolling. Only intended for use within web-client.
    * If using within a modal, wrap the list within a .modal-list-container to preserve sticky behavior. Defaults to true.
    **/
    stickyHeader: boolean;
    /**
    * Optional template for either a clickable drawer beneath each list item OR a modal on desktop/tablet.
    * Always opens in a modal on mobile devices.
    **/
    detailsTemplate: TemplateRef<any>;
    /**
    * Whether or not the desktop details template should render in a drawer. Defaults to true; set to false to render in a modal.
    **/
    detailsTemplateIsDrawer: boolean;
    /**
    * Optional. Locks the details modal scrim, preventing the user from closing the modal by clicking outside of it.
    * Defaults to false. Content modals should generally have unlocked scrims for ADA reasons —
    * users, especially keyboard users, rely on scrim dismissal as a standard affordance.
    **/
    lockDetailsModalScrim: boolean;
    /**
    * Optional title for the modal which renders the list item details.
    **/
    detailsTemplateTitle: string;
    /**
    * The text of an optional primary button within the list item details drawer/modal.
    **/
    detailsPrimaryButtonText: string;
    /**
    * The text of an optional secondary button within the list item details drawer/modal.
    **/
    detailsSecondaryButtonText: string;
    /**
    * The text of an optional tertiary button within the list item details drawer/modal.
    **/
    detailsTertiaryButtonText: string;
    /**
    * The icon of an optional tertiary button within the list item details drawer/modal.
    **/
    detailsTertiaryButtonIcon: string;
    /**
    * Optional text used to override the default "No Items" title text.
    **/
    noListItemsTitleText: string;
    /**
    * Optional text used to override the default "no list items to display" subtitle text.
    **/
    noListItemsSubtitleText: string;
    /**
    * Optional text used to override the default "you've reached the end of list" subtitle text.
    * This text will only appear when the "pageSize" is set.
    **/
    endOfListText: string;
    /**
    * Specifies whether to show search / sort / filter functionality for the list. Defaults to false.
    **/
    searchEnabled: boolean;
    /**
    * Optional text used to override the default placeholder text for the search field.
    **/
    searchFieldPlaceholder: string;
    /**
    * Optional text used to manually set the search field value.
    **/
    searchFieldText: string;
    /**
    * Optional array of PickerOptions that are used to sort the list.
    **/
    sortOptions: PickerOption<string>[];
    /**
    * Optional value of the default sort option.
    **/
    sortOptionDefaultValue: string;
    /**
    * The available customized list filters to show. Each SearchSortFilter must define a list of options.
    **/
    customFilters: SearchSortFilter[];
    /**
    * Specifies whether to include the standard date filters. Defaults to false.
    **/
    includeDateFilters: boolean;
    /**
    * If "includeDateFilters" is true, this flag determines whether to use "past" or "future" date filters.
    * Defaults to false ("past" date filters).
    **/
    useFutureDateFilters: boolean;
    /**
    * If "showBorder" is true, a rounded border will be shown around the list. Defaults to true.
    **/
    showBorder: boolean;
    /**
    * Array of actions to show in floating actions bar at the bottom of the list.
    **/
    bulkActions: BulkAction[];
    /**
    * Optional array of "checked" items (of class ListItem).
    * When "bulkActions" is specified, this array is used for managing selection state.
    **/
    checkedItems: ListItem[];
    /**
    * Specifies the total number of list items. Only needed when using the "checkbox" selection mode with Search enabled.
    **/
    totalItemCount: number;
    /**
    * E2E testing - data-e2e attribute attached to the list.
    **/
    e2e: string;
    /**
    * Emits search value on change.
    **/
    searched: EventEmitter<string>;
    /**
    * Emits sort value when the sort option is changed.
    **/
    sorted: EventEmitter<string>;
    /**
    * Emits all available filters when a filter value is changed.
    **/
    filtered: EventEmitter<SearchSortFilter[]>;
    /**
    * Emits all available filters and a boolean that specifies whether to refilter when the "Clear All" filters
    * button is clicked. A true value (the default) means that the list should be refiltered.
    **/
    filtersCleared: EventEmitter<{
        filters: SearchSortFilter[];
        refilter: boolean;
    }>;
    /**
    * Emits when the mobile "View All" modal is closed.
    **/
    mobileViewAllModalClosed: EventEmitter<void>;
    /**
    * When a checkbox or toggle is clicked, the ListItem is emitted with an updated "checked" property.
    **/
    controlToggled: EventEmitter<ListItem>;
    /**
    * Emits a ListItem when a list row is clicked, which allows the parent component to navigate to a new page, open a modal, etc.
    **/
    listRowClicked: EventEmitter<ListItem>;
    /**
    * Emits when the "Show More" button is clicked.
    **/
    showMoreButtonClicked: EventEmitter<void>;
    /**
    * Emits when a bulk action is clicked.
    **/
    bulkAction: EventEmitter<BulkActionEvent>;
    /**
    * Emits when the bulk action's "Clear All" button is clicked.
    **/
    bulkActionsCleared: EventEmitter<void>;
    /**
    * Emits the current ListItem when the primary button within the drawer/modal is clicked.
    **/
    detailsPrimaryButtonClicked: EventEmitter<ListItem>;
    /**
    * Emits the current ListItem when the secondary button within the drawer/modal is clicked.
    **/
    detailsSecondaryButtonClicked: EventEmitter<ListItem>;
    /**
    * Emits the current ListItem when the tertiary button within the drawer/modal is clicked.
    **/
    detailsTertiaryButtonClicked: EventEmitter<ListItem>;
    HtmlAttributeStateEnum: typeof HtmlAttributeState;
    bulkActionsSelectedLabel: string;
    e2ePrefix: string;
    detailModalE2E: string;
    isMobile: boolean;
    isMobileViewAllModalOpen: boolean;
    listId: string;
    listItemHeaders: ListItemHeader[];
    numItemsToShow: number;
    numModalItemsToShow: number;
    selectAllCheckboxChecked: boolean;
    selectAllCheckboxIndeterminate: boolean;
    selectedItem: ListItem;
    showMoreClicked: boolean;
    toggledOffAriaLabel: string;
    toggledOnAriaLabel: string;
    autoFocusSearchInput: boolean;
    searchInputChanged: boolean;
    showSearchSortFilter: boolean;
    private intersectionObserver?;
    private lazyLoadSentinelEl?;
    set lazyLoadSentinel(el: ElementRef<HTMLElement> | undefined);
    constructor(dateProvider: DateProvider, modalService: ModalService, textService: TextService, windowService: WindowService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    onToggle(item: ListItem, checked: boolean): void;
    onListRowClick(item: ListItem): void;
    private showItemDetails;
    detailsPrimaryButtonClick(): void;
    detailsSecondaryButtonClick(): void;
    detailsTertiaryButtonClick(): void;
    private populateListItemHeadersAndE2E;
    private getDateString;
    onSearchToggleClick(): void;
    onSearchChange(searchText: string): void;
    onSortChange(value: string): void;
    onFilterChange(filters: SearchSortFilter[]): void;
    onFilterClearAllChange(event: {
        filters: SearchSortFilter[];
        refilter: boolean;
    }): void;
    onSelectAllChange(checked: boolean): void;
    onDetailsModalClose(): void;
    closeMobileViewAllModal(): void;
    clearAllFilters(): void;
    resetPageSize(): void;
    showMore(): void;
    doBulkAction(action: BulkAction): void;
    clearBulkActions(): void;
    private observeLazyLoadSentinel;
    private disconnectIntersectionObserver;
    ngOnDestroy(): void;
    private openMobileViewAllModal;
    private setE2EPrefix;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListComponent, "ui-workflows-list", never, { "items": { "alias": "items"; "required": false; }; "pageSize": { "alias": "pageSize"; "required": false; }; "lazyLoad": { "alias": "lazyLoad"; "required": false; }; "lazyLoadTriggerDistance": { "alias": "lazyLoadTriggerDistance"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; "allowEmojis": { "alias": "allowEmojis"; "required": false; }; "threadModeEnabled": { "alias": "threadModeEnabled"; "required": false; }; "selectionMode": { "alias": "selectionMode"; "required": false; }; "selectionToggledOffAriaLabel": { "alias": "selectionToggledOffAriaLabel"; "required": false; }; "selectionToggledOnAriaLabel": { "alias": "selectionToggledOnAriaLabel"; "required": false; }; "hideRightContentOnMobile": { "alias": "hideRightContentOnMobile"; "required": false; }; "clickable": { "alias": "clickable"; "required": false; }; "clickableIcon": { "alias": "clickableIcon"; "required": false; }; "clickableLabel": { "alias": "clickableLabel"; "required": false; }; "header": { "alias": "header"; "required": false; }; "stickyHeader": { "alias": "stickyHeader"; "required": false; }; "detailsTemplate": { "alias": "detailsTemplate"; "required": false; }; "detailsTemplateIsDrawer": { "alias": "detailsTemplateIsDrawer"; "required": false; }; "lockDetailsModalScrim": { "alias": "lockDetailsModalScrim"; "required": false; }; "detailsTemplateTitle": { "alias": "detailsTemplateTitle"; "required": false; }; "detailsPrimaryButtonText": { "alias": "detailsPrimaryButtonText"; "required": false; }; "detailsSecondaryButtonText": { "alias": "detailsSecondaryButtonText"; "required": false; }; "detailsTertiaryButtonText": { "alias": "detailsTertiaryButtonText"; "required": false; }; "detailsTertiaryButtonIcon": { "alias": "detailsTertiaryButtonIcon"; "required": false; }; "noListItemsTitleText": { "alias": "noListItemsTitleText"; "required": false; }; "noListItemsSubtitleText": { "alias": "noListItemsSubtitleText"; "required": false; }; "endOfListText": { "alias": "endOfListText"; "required": false; }; "searchEnabled": { "alias": "searchEnabled"; "required": false; }; "searchFieldPlaceholder": { "alias": "searchFieldPlaceholder"; "required": false; }; "searchFieldText": { "alias": "searchFieldText"; "required": false; }; "sortOptions": { "alias": "sortOptions"; "required": false; }; "sortOptionDefaultValue": { "alias": "sortOptionDefaultValue"; "required": false; }; "customFilters": { "alias": "customFilters"; "required": false; }; "includeDateFilters": { "alias": "includeDateFilters"; "required": false; }; "useFutureDateFilters": { "alias": "useFutureDateFilters"; "required": false; }; "showBorder": { "alias": "showBorder"; "required": false; }; "bulkActions": { "alias": "bulkActions"; "required": false; }; "checkedItems": { "alias": "checkedItems"; "required": false; }; "totalItemCount": { "alias": "totalItemCount"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; }, { "searched": "searched"; "sorted": "sorted"; "filtered": "filtered"; "filtersCleared": "filtersCleared"; "mobileViewAllModalClosed": "mobileViewAllModalClosed"; "controlToggled": "controlToggled"; "listRowClicked": "listRowClicked"; "showMoreButtonClicked": "showMoreButtonClicked"; "bulkAction": "bulkAction"; "bulkActionsCleared": "bulkActionsCleared"; "detailsPrimaryButtonClicked": "detailsPrimaryButtonClicked"; "detailsSecondaryButtonClicked": "detailsSecondaryButtonClicked"; "detailsTertiaryButtonClicked": "detailsTertiaryButtonClicked"; }, never, never, false, never>;
}

declare enum ListFormFieldType {
    AMOUNT = "AMOUNT",
    DATEPICKER = "DATEPICKER",
    NUMBER = "NUMBER"
}

declare class ListFormField {
    type: ListFormFieldType;
    label: string;
    name: string;
    errorMessage: string;
    required: boolean;
    afterDateText: string;
    disableFutureDates: boolean;
    disablePastDates: boolean;
    disableHolidays: boolean;
    disableWeekends: boolean;
    holidays: Holiday[];
    priorDateText: string;
    selectedDateText: string;
    min: number;
    max: number;
    decimalPlaces: number;
    readonly _initialValue: string | number;
    constructor(type: ListFormFieldType, label: string, name: string);
    getValidator(): (value: any) => ValidationResult;
}

declare class ListFormItem extends ListItem {
    initialValues: Map<string, string | number>;
    daysAfter: number;
    daysPrior: number;
    maxDate: Date;
    minDate: Date;
    _canBeSubmitted: boolean;
    _form: UntypedFormGroup;
    get canBeSubmitted(): boolean;
    get form(): UntypedFormGroup;
    getFormItemInitialValue(name: string): number | string | null;
    getFormFieldValue(name: string): number | string | null;
    resetFormFieldValues(fields: ListFormField[]): void;
}

declare class ListFormComponent extends BaseTextComponent implements OnInit, OnChanges {
    private fb;
    private modalService;
    private textService;
    private windowService;
    detailsModal: TemplateRef<any>;
    searchComponent: SearchInputComponent;
    private unsavedChangesModal;
    /**
    * Required. The array of form fields (of class ListFormField) with validation.
    * Only Amount, Number and Date fields are supported. Only 2 fields are allowed.
    **/
    formFields: ListFormField[];
    /**
    * Required. The array of items (of class ListFormItem) to render in a list.
    **/
    items: ListFormItem[];
    /**
    * Specifies the number of items to display on each "page". Set to "undefined" for no pagination.
    **/
    pageSize: number;
    /**
    * Optional title for the modal that renders when a list item is clicked.
    **/
    modalTitle: string;
    /**
    * Optional. Locks the modal scrim, preventing the user from closing the modal by clicking outside of it or pressing the Escape key.
    * Defaults to false. Note that locking the scrim also blocks the Escape key — on desktop this removes a standard
    * keyboard affordance, so only set to true for modals where preventing accidental dismissal outweighs that ADA concern.
    * Avoid setting both lockModalScrim and confirmUnsavedChanges to true — they are not designed to be used together.
    **/
    lockModalScrim: boolean;
    /**
    * Optional. When true, prompts the user to confirm before closing the modal if the form has unsaved changes.
    * Defaults to false. Avoid setting both confirmUnsavedChanges and lockModalScrim to true — they are not designed to be used together.
    **/
    confirmUnsavedChanges: boolean;
    readonly checkUnsavedChangesHandler: any;
    /**
    * Optional template for the top of the modal that renders when a list item is clicked.
    **/
    modalTopTemplate: TemplateRef<any>;
    /**
    * Optional template for the bottom of the modal that renders when a list item is clicked.
    **/
    modalBottomTemplate: TemplateRef<any>;
    /**
    * The text of an optional primary button within the modal.
    **/
    modalPrimaryButtonText: string;
    /**
    * The text of an optional secondary button within the modal.
    **/
    modalSecondaryButtonText: string;
    /**
    * The text of an optional tertiary button within the modal.
    **/
    modalTertiaryButtonText: string;
    /**
    * The icon of an optional tertiary button within the modal.
    **/
    modalTertiaryButtonIcon: string;
    /**
    * Optional text used to override the default "No Items" title text.
    **/
    noListItemsTitleText: string;
    /**
    * Optional text used to override the default "no list items to display" subtitle text.
    **/
    noListItemsSubtitleText: string;
    /**
    * Optional text used to override the default "you've reached the end of list" subtitle text.
    **/
    endOfListText: string;
    /**
    * Specifies whether to show search / sort / filter functionality for the list. Defaults to true.
    **/
    searchEnabled: boolean;
    /**
    * Optional text used to override the default placeholder text for the search field.
    **/
    searchFieldPlaceholder: string;
    /**
    * Optional text used to manually set the search field value.
    **/
    searchFieldText: string;
    /**
    * Optional array of PickerOptions that are used for sorting the list.
    **/
    sortOptions: PickerOption<string>[];
    /**
    * Optional value of the default sort option.
    **/
    sortOptionDefaultValue: string;
    /**
    * E2E testing - data-e2e attribute attached to the list.
    **/
    e2e: string;
    /**
    * Emits search value on change.
    **/
    searched: EventEmitter<string>;
    /**
    * Emits sort value when the sort option is changed.
    **/
    sorted: EventEmitter<string>;
    /**
    * Emits when the "Show More" button is clicked.
    **/
    showMoreButtonClicked: EventEmitter<void>;
    /**
    * Emits the currently selected ListFormItem when the primary button within the modal is clicked.
    **/
    primaryButtonClicked: EventEmitter<ListFormItem>;
    /**
    * Emits the currently selected ListFormItem when the secondary button within the modal is clicked.
    **/
    secondaryButtonClicked: EventEmitter<ListFormItem>;
    /**
    * Emits the currently selected ListFormItem when the tertiary button within the modal is clicked.
    **/
    tertiaryButtonClicked: EventEmitter<ListFormItem>;
    /**
    * Emits a ListFormItem object when a list form item's modal opens.
    **/
    itemModalOpened: EventEmitter<ListFormItem>;
    /**
    * Emits a ListFormItem object when a list form item's field value in the list changes.
    **/
    itemChange: EventEmitter<ListFormItem>;
    /**
    * Emits when the valid list form items change.
    **/
    validItemsChange: EventEmitter<void>;
    HtmlAttributeStateEnum: typeof HtmlAttributeState;
    ListFormFieldType: typeof ListFormFieldType;
    e2ePrefix: string;
    isMobile: boolean;
    listId: string;
    numItemsToShow: number;
    searchInputChanged: boolean;
    showMoreClicked: boolean;
    selectedItem: ListFormItem;
    allFields: ListFormField[];
    constructor(fb: UntypedFormBuilder, modalService: ModalService, textService: TextService, windowService: WindowService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    private buildItemForms;
    emitAndValidateItem(item: ListFormItem): void;
    private validateItemForm;
    getMobileValue(item: ListFormItem, field: ListFormField): string | number;
    private buildForm;
    private getValidatorFunc;
    openDetailsModal(item: ListFormItem): void;
    showMore(): void;
    onPrimaryButtonClick(): void;
    onSecondaryButtonClick(): void;
    onTertiaryButtonClick(): void;
    onSearchChange(searchText: string): void;
    onSortChange(value: string): void;
    private checkUnsavedChanges;
    private setE2EPrefix;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListFormComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListFormComponent, "ui-workflows-list-form", never, { "formFields": { "alias": "formFields"; "required": false; }; "items": { "alias": "items"; "required": false; }; "pageSize": { "alias": "pageSize"; "required": false; }; "modalTitle": { "alias": "modalTitle"; "required": false; }; "lockModalScrim": { "alias": "lockModalScrim"; "required": false; }; "confirmUnsavedChanges": { "alias": "confirmUnsavedChanges"; "required": false; }; "modalTopTemplate": { "alias": "modalTopTemplate"; "required": false; }; "modalBottomTemplate": { "alias": "modalBottomTemplate"; "required": false; }; "modalPrimaryButtonText": { "alias": "modalPrimaryButtonText"; "required": false; }; "modalSecondaryButtonText": { "alias": "modalSecondaryButtonText"; "required": false; }; "modalTertiaryButtonText": { "alias": "modalTertiaryButtonText"; "required": false; }; "modalTertiaryButtonIcon": { "alias": "modalTertiaryButtonIcon"; "required": false; }; "noListItemsTitleText": { "alias": "noListItemsTitleText"; "required": false; }; "noListItemsSubtitleText": { "alias": "noListItemsSubtitleText"; "required": false; }; "endOfListText": { "alias": "endOfListText"; "required": false; }; "searchEnabled": { "alias": "searchEnabled"; "required": false; }; "searchFieldPlaceholder": { "alias": "searchFieldPlaceholder"; "required": false; }; "searchFieldText": { "alias": "searchFieldText"; "required": false; }; "sortOptions": { "alias": "sortOptions"; "required": false; }; "sortOptionDefaultValue": { "alias": "sortOptionDefaultValue"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; }, { "searched": "searched"; "sorted": "sorted"; "showMoreButtonClicked": "showMoreButtonClicked"; "primaryButtonClicked": "primaryButtonClicked"; "secondaryButtonClicked": "secondaryButtonClicked"; "tertiaryButtonClicked": "tertiaryButtonClicked"; "itemModalOpened": "itemModalOpened"; "itemChange": "itemChange"; "validItemsChange": "validItemsChange"; }, never, never, false, never>;
}

declare enum DateFilterType {
    CUSTOM = "CUSTOM",
    LAST_7_DAYS = "LAST_7_DAYS",
    LAST_30_DAYS = "LAST_30_DAYS",
    LAST_365_DAYS = "LAST_365_DAYS",
    NEXT_30_DAYS = "NEXT_30_DAYS",
    NEXT_60_DAYS = "NEXT_60_DAYS",
    PAST_90_DAYS = "PAST_90_DAYS",
    PAST_180_DAYS = "PAST_180_DAYS",
    PAST_MONTH = "PAST_MONTH",
    PAST_WEEK = "PAST_WEEK",
    PAST_YEAR = "PAST_YEAR",
    PREVIOUS_BUSINESS_DAY = "PREVIOUS_BUSINESS_DAY",
    THIS_MONTH = "THIS_MONTH",
    THIS_YEAR = "THIS_YEAR",
    TODAY = "TODAY"
}

declare class ColumnFilterControl {
    label?: string;
    options: ColumnFilterOption[];
    propertyName: string;
    rangeAllowed?: Date[] | number[];
    type?: TableFilterType;
    _value?: number[];
}
declare class ColumnFilterOption {
    checked?: boolean;
    label?: string;
    value: string;
}
declare class ColumnFilterList {
    [key: string]: string[];
}
declare class TableFilter {
    criteria: string;
    activeFilters: string[];
    allSelected: boolean;
    noneSelected: boolean;
}
declare class TableFilterEvent {
    filters?: TableFilter[];
    searchTerm?: string;
    filteredData?: any[];
}
declare enum TableFilterType {
    STRING = "string",
    DATE_RANGE = "date-range"
}

declare class TableActionEvent {
    eventName: string;
    eventData: any;
}

declare class TableAction {
    action: (dataItem: any) => TableActionEvent;
    icon?: string;
    text: string;
    visible?: (object: any) => boolean;
}

declare class TableActionsComponent implements OnChanges {
    actions: TableAction[];
    item: any;
    menuTitle: string;
    tableAction: EventEmitter<TableAction>;
    buttonActions: ButtonMenuOption[];
    ngOnChanges(): void;
    private filterActions;
    static ɵfac: i0.ɵɵFactoryDeclaration<TableActionsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TableActionsComponent, "ui-workflows-table-actions", never, { "actions": { "alias": "actions"; "required": false; }; "item": { "alias": "item"; "required": false; }; "menuTitle": { "alias": "menuTitle"; "required": false; }; }, { "tableAction": "tableAction"; }, never, never, false, never>;
}

declare class TableBadgesContext {
    badges: BadgeModel[];
}
declare class TableIconContext extends IconComponent {
    iconPosition?: 'left' | 'right';
    subtext?: string;
    text?: string;
}

declare class TableCellContent {
    text?: string;
    subtext?: string;
    searchText?: string;
    html?: string;
}

declare class TableRow {
    [columnName: string]: any;
    _tData?: TableRowData;
}
declare class TableColumnData {
    text?: string;
    sortLabel?: string;
    sortName?: string;
    template?: TemplateRef<any>;
    width?: string;
    wrapClass?: string;
}
declare class TableRowData {
    checked?: boolean;
    hasBulkActions?: boolean;
    hasRowActions?: boolean;
    [columnName: string]: TableRowColumnData | any;
    searchText?: string;
}
declare class TableRowColumnData {
    formatted?: TableCellContent;
    filterValue?: string | string[] | number;
    templateContext?: any;
    tooltip?: string;
}

declare class TableColumn {
    align?: 'left' | 'center' | 'right';
    clickable?: boolean;
    columnTemplate?: string | TemplateRef<any>;
    contentClass?: string;
    date?: boolean;
    dateFormat?: string;
    displayName?: string | TableCellContent;
    filterable?: boolean;
    filterOptions?: ColumnFilterOption[];
    formatFn?: (data: any, row: any, column: TableColumn) => string | TableCellContent;
    headerClass?: string;
    minWidth?: number;
    propertyName: string;
    searchable?: boolean;
    sortable?: boolean;
    sortColumnName?: string;
    sortFn?: (data: any, row: any, column: TableColumn) => string;
    templateContextFn?: (data: any, row: any, column: TableColumn) => any;
    toolTipFn?: (data: any, row: any, column: TableColumn) => string;
    width?: string;
    wrap?: 'force' | 'none';
    _tData?: TableColumnData;
    allowBlankFilter?: boolean;
}
declare enum TableStickyColumnConfig {
    FIRST = "first",
    LAST = "last",
    BOTH = "both",
    NONE = "none"
}

declare enum TableSortDirection {
    ASCENDING = "ASC",
    DESCENDING = "DESC"
}

declare class TableState {
    currentPage: number;
    filters: ColumnFilterList;
    pageSize: number;
    searchTerm: string;
    sortColumn: string;
    sortDirection: TableSortDirection;
    get sortTerm(): string;
    static buildSortTerm(column: string, direction: TableSortDirection): string;
    clone(): TableState;
}

declare class TableStateService {
    private tableStates;
    private idDelimiter;
    saveState(tableStateId: string, state: TableState, tableStateParam?: string): void;
    getState(tableStateId: string, tableStateParam?: string): TableState | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<TableStateService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TableStateService>;
}

declare class TableTemplatesService {
    private tableTemplates;
    private areTemplatesLoaded;
    templatesLoaded$: rxjs.Observable<boolean>;
    add(name: string, ref: TemplateRef<any>): void;
    get(name: string): TemplateRef<any>;
    static ɵfac: i0.ɵɵFactoryDeclaration<TableTemplatesService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<TableTemplatesService>;
}

declare class TableComponent<T> extends BaseTextComponent implements OnInit, OnChanges, AfterViewInit {
    private tableStateService;
    private tableTemplatesService;
    private windowService;
    private changeDetector;
    private ngZone;
    protected textService: TextService;
    tableScroller: ElementRef;
    /**
    * Use "external" control mode for paging and sorting.
    * boolean: false by default, which means all data is loaded initially & the table will perform all actions internally (client-side)
    * If true, the table will only emit sort & page events, and not do any client-side sorting or paging.
    * this can be safely toggled to false by the parent component if/when all data is loaded
    **/
    externalSortAndPaging: boolean;
    /**
     * Use "external" control mode for searching and filtering.
     * boolean: false by default, which means all data is loaded initially & the table will perform all actions internally (client-side)
     * If true, the table will only emit search & filter events, but not do any client-side filtering or searching. (filterOptions must be provided by parent component)
     * If set to true, this SHOULD NOT be dynamically toggled by the parent component. We can't safely filter or search if we don't know if we have all the data, it must rely on the API requests (future work possible).
     */
    externalSearchAndFilter: boolean;
    /**
    * Array of actions to show in Actions column (menu if multiple, single button if single)
    **/
    actions: TableAction[];
    /**
    * CSS width attribute of actions column
    **/
    actionsColumnFixedWidth: string;
    /**
    * Array of actions to show in floating actions bar
    **/
    bulkActions: TableAction[];
    /**
    * Array of TableColumn objects used to define table structure
    **/
    columns: TableColumn[];
    /**
    * Array of data objects that will be processed by the TableColumns in this.columns, and displayed
    **/
    data: T[];
    /**
    * Array of strings representing properties on the data object that should be searched when a search term is provided.
    * These are for "hidden" properties that are not already part of a column. These searchable properties can be strings, numbers, or an array of either.
    **/
    searchableProps: string[];
    /**
    * E2E testing - data-e2e attribute attached to table
    **/
    e2e: string;
    /**
    * String text to display if data is empty, or filtered to 0
    **/
    emptyText: string;
    /**
    * Boolean to show/hide grid-lines between cells
    **/
    gridLines: boolean;
    /**
    * Number of current page
    **/
    page: number;
    /**
    * Number of items to display per page
    **/
    pageSize: number;
    /**
    * Array of numbers used to populate page size dropdown
    **/
    pageSizes: number[];
    /**
    * Number of items in the table (total)
    **/
    resultCount: number;
    /**
    * String value of search query, will automatically search/filter if provided
    **/
    searchTerm: string;
    /**
    * Boolean to show a checkbox on each row, and a "Select All" checkbox at the top of the column. Emits rowChecked when checked/unchecked
    **/
    showCheckbox: boolean;
    /**
    * Boolean to show or hide the column title & sort headers
    **/
    showColumnHeaders: boolean;
    /**
    * Boolean to show or hide the paging & page controls
    **/
    showPageControls: boolean;
    /**
    * Boolean to show or hide the search input & filters
    **/
    showSearchAndFilter: boolean;
    /**
    * Boolean to determine search input width - if true it will stretch across the whole table header
    **/
    searchFullWidth: boolean;
    /**
    * String name of column to sort by initially
    **/
    sortColumn: string;
    /**
    * Direction of initial sort
    **/
    sortDirection: TableSortDirection;
    /**
    * Sets which columns will be sticky/frozen when scrolling
    **/
    stickyColumns: TableStickyColumnConfig;
    /**
    * Boolean to show alternating row background colors
    **/
    striped: boolean;
    /**
    * String property to attach to data row/item when an Action is processing it
    **/
    tableActionProcessingProp: string;
    /**
    * String id of table. Must be unique per table, and is required to maintain usage-specific state.
    * Keeps table state on navigation. Caches sort/search/filter/paging state in onDestroy.
    **/
    tableStateId: string;
    /**
    * String parameter to more specifically define the tableState id.
    * example: using a userId so that session log states can be maintained when viewing multiple users.
    **/
    tableStateParam: string;
    /**
    * Boolean to indicate that user's sort/search/filter/paging selections should persist when the data changes.
    * Keeps table state on data update. Set to `false` & don't set a "tableStateId" if you need the table state to reset when the data updates.
    **/
    keepStateOnUpdate: boolean;
    /**
    * Title text to be displayed above table
    **/
    title: string;
    /**
    * Subtitle text to be displayed above table
    **/
    subtitle: string;
    /**
    * Optional badges that render next to the title/subtitle
    **/
    badges: BadgeModel[];
    /**
    * Array of Page Actions to show in header/title row above the table
    * These do not provide or act on Table data, but are available for additional actions
    **/
    headerActions: PageActionItem[];
    /**
    * Optional. Sets the header page actions more menu button icon. Defaults to three vertical dots.
    **/
    pageActionsMenuIcon: string;
    /**
    * Optional. Sets the header page actions more menu button text. Defaults to 'More'.
    **/
    pageActionsMenuText: string;
    /**
    * Emits row data item when a row is clicked/enter-key. Only emits if a column is marked as clickable.
    **/
    rowClicked: EventEmitter<T>;
    /**
    * Emits when a row action is clicked/enter-key
    **/
    tableAction: EventEmitter<TableActionEvent | BulkActionEvent>;
    /**
    * Emits array of currently checked rows when a row (or select-all) checkbox is checked/unchecked
    **/
    rowChecked: EventEmitter<T[]>;
    /**
    * Emits list of active filters when filters are changed
    **/
    filtersChanged: EventEmitter<TableFilterEvent>;
    /**
    * Emits new page number when a new page is requested
    **/
    pageChanged: EventEmitter<number>;
    /**
    * Emits new page size when size is changed
    **/
    pageSizeChanged: EventEmitter<number>;
    /**
    * Emits searchTerm string when a search is requested
    **/
    searched: EventEmitter<TableFilterEvent>;
    /**
    * Emits sort term ${column}~${direction} when column is sorted
    **/
    sorted: EventEmitter<string>;
    MIN_COL_WIDTH: string;
    actionsColMinWidth: string;
    activeFilters: ColumnFilterList;
    bulkActionsVisible: TableAction[];
    bulkActionRows: TableRow[];
    bulkActionsSelectedLabel: string;
    clickable: boolean;
    dataPage: TableRow[];
    dataPageList: number[];
    filters: ColumnFilterControl[];
    filteredData: TableRow[];
    firstColFixed: boolean;
    firstColContent: boolean;
    hasActiveFilters: boolean;
    hasActionsColumn: boolean;
    isMobile: boolean;
    isSelectAllChecked: boolean;
    lastColFixed: boolean;
    lastColContent: boolean;
    pages: number[];
    pageSizeOptions: PickerOption<number>[];
    pageSizeText: string;
    scrollable: boolean;
    scrollLeftComplete: boolean;
    scrollRightComplete: boolean;
    stickyClass: string;
    templatesReady: boolean;
    TableSortDirection: typeof TableSortDirection;
    TableFilterType: typeof TableFilterType;
    private _data;
    private _externalSearchAndFilter;
    private animationFrameTick;
    private buildingFilters;
    private hasState;
    private initPageSize;
    private isSelectAll;
    private isSelectRow;
    private searchTermPartsUC;
    private sortKeyPrefix;
    private tableState;
    private minDateValue;
    private maxDateValue;
    constructor(tableStateService: TableStateService, tableTemplatesService: TableTemplatesService, windowService: WindowService, changeDetector: ChangeDetectorRef, ngZone: NgZone, textService: TextService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    onScroll(): void;
    sortOnColumn(column: TableColumn): void;
    doTableAction(row: TableRow, action: TableAction): void;
    doBulkTableAction(action: BulkAction): void;
    rowClick(row: TableRow, event: Event): void;
    onSelectRow(row: TableRow, isSelectAll?: boolean): void;
    onSelectAll(event: Event | false): void;
    changePageSize(pageSizeNumber: number): void;
    changePage(pageNumber: any): void;
    setRowHighlight(event: KeyboardEvent, turnOff?: boolean): void;
    doSearch(searchTerm: string): void;
    onFilterChange(selectedOptions: string[], filter: ColumnFilterControl): void;
    private updateFilterOptions;
    clearAllFilters(): void;
    private prepData;
    private getCellContent;
    private setupFilters;
    private setupSortAndPaging;
    private setupPaging;
    private setDisplayPages;
    private getSortColumnName;
    private doSort;
    private setupColumns;
    private hasRowActions;
    private getBulkActions;
    private createFilterOptions;
    private filterData;
    private isDateRangeFilter;
    private updateTableControls;
    private handleChecked;
    private checkForSelectAll;
    private setScrollState;
    private removeTableRowData;
    private removeTableRowDataFromList;
    private emitFilters;
    private saveState;
    private restoreState;
    private resetState;
    private clearFilterState;
    private setSearchHighlight;
    private getSearchTextRanges;
    private searchNodesForTerm;
    private clearSearchHighlights;
    private dateStringToInt;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<TableComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TableComponent<any>, "ui-workflows-table", never, { "externalSortAndPaging": { "alias": "externalSortAndPaging"; "required": false; }; "externalSearchAndFilter": { "alias": "externalSearchAndFilter"; "required": false; }; "actions": { "alias": "actions"; "required": false; }; "actionsColumnFixedWidth": { "alias": "actionsColumnFixedWidth"; "required": false; }; "bulkActions": { "alias": "bulkActions"; "required": false; }; "columns": { "alias": "columns"; "required": false; }; "data": { "alias": "data"; "required": false; }; "searchableProps": { "alias": "searchableProps"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; "emptyText": { "alias": "emptyText"; "required": false; }; "gridLines": { "alias": "gridLines"; "required": false; }; "page": { "alias": "page"; "required": false; }; "pageSize": { "alias": "pageSize"; "required": false; }; "pageSizes": { "alias": "pageSizes"; "required": false; }; "resultCount": { "alias": "resultCount"; "required": false; }; "searchTerm": { "alias": "searchTerm"; "required": false; }; "showCheckbox": { "alias": "showCheckbox"; "required": false; }; "showColumnHeaders": { "alias": "showColumnHeaders"; "required": false; }; "showPageControls": { "alias": "showPageControls"; "required": false; }; "showSearchAndFilter": { "alias": "showSearchAndFilter"; "required": false; }; "searchFullWidth": { "alias": "searchFullWidth"; "required": false; }; "sortColumn": { "alias": "sortColumn"; "required": false; }; "sortDirection": { "alias": "sortDirection"; "required": false; }; "stickyColumns": { "alias": "stickyColumns"; "required": false; }; "striped": { "alias": "striped"; "required": false; }; "tableActionProcessingProp": { "alias": "tableActionProcessingProp"; "required": false; }; "tableStateId": { "alias": "tableStateId"; "required": false; }; "tableStateParam": { "alias": "tableStateParam"; "required": false; }; "keepStateOnUpdate": { "alias": "keepStateOnUpdate"; "required": false; }; "title": { "alias": "title"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "badges": { "alias": "badges"; "required": false; }; "headerActions": { "alias": "headerActions"; "required": false; }; "pageActionsMenuIcon": { "alias": "pageActionsMenuIcon"; "required": false; }; "pageActionsMenuText": { "alias": "pageActionsMenuText"; "required": false; }; }, { "rowClicked": "rowClicked"; "tableAction": "tableAction"; "rowChecked": "rowChecked"; "filtersChanged": "filtersChanged"; "pageChanged": "pageChanged"; "pageSizeChanged": "pageSizeChanged"; "searched": "searched"; "sorted": "sorted"; }, never, never, false, never>;
}

declare enum TableTemplateType {
    BADGES = "badges",
    ICON = "icon",
    TAGS = "tags",
    _READY = "_ready"
}

declare class TableTemplatesDefinitionsComponent {
    tableTemplatesService: TableTemplatesService;
    BadgeTheme: typeof BadgeTheme;
    TableTemplateType: typeof TableTemplateType;
    constructor(tableTemplatesService: TableTemplatesService);
    static ɵfac: i0.ɵɵFactoryDeclaration<TableTemplatesDefinitionsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TableTemplatesDefinitionsComponent, "ui-workflows-table-template-definitions", never, {}, {}, never, never, false, never>;
}

declare class TableTemplateUtils {
    static buildTagList(items: string[] | string): {
        tags: ChipListItem[];
    };
}

declare enum FrequencyType {
    ONE_TIME_FUTURE = "ONE_TIME_FUTURE",// One time, but the date is picked
    RECURRING = "RECURRING",// Recurring, must pick start/end behaviors
    TWO_DAYS_A_MONTH = "TWO_DAYS_A_MONTH"
}

declare class FrequencyOption {
    label: string;
    id: string;
    type: FrequencyType;
    startDateLabel: string;
    startDateActionButtonLabel: string;
    startDateActionButtonIcon: string;
    startDateDisableAllExceptFirstDayOfMonth: boolean;
    startDateDisableAllExceptLastDayOfMonth: boolean;
    startDateDisableAllExceptFifteenthAndLastDay: boolean;
    firstDayLabel: string;
    firstDayDescription: string;
    secondDayLabel: string;
    secondDayDescription: string;
    dayBuffer: number;
    dayBufferMessage: string;
}

interface FormWorkflowComponent {
    validate: () => FormWorkflowResult | null;
}
interface FormWorkflowResult {
    isValid: boolean;
}

declare class FundingOptionsResult implements FormWorkflowResult {
    fromValue: string;
    toValue: string;
    fromSelection: any;
    toSelection: any;
    get isValid(): boolean;
}

declare class FundingOptionsComponent<TFrom extends BaseTemplateData, TTo extends BaseTemplateData> extends BaseTextComponent implements OnChanges, OnInit, FormWorkflowComponent {
    private fb;
    private windowService;
    protected textService: TextService;
    /**
    * Fund from options.
    **/
    fromGroups: TemplateGroup<TFrom>[];
    /**
    * Fund to options.
    **/
    toGroups: TemplateGroup<TTo>[];
    /**
    * Actions inside the from dropdown.
    **/
    fromActions: DropdownAction[];
    /**
    * Actions inside the to dropdown.
    **/
    toActions: DropdownAction[];
    /**
    * The initial value of the from dropdown.
    **/
    initialFromValue: string;
    /**
    * The initial value of the to dropdown.
    **/
    initialToValue: string;
    /**
    * If the from dropdown should be locked.
    * Note: If there are available actions, this value will be disregarded.
    **/
    lockedFrom: boolean;
    /**
    * If the to dropdown should be locked.
    * Note: If there are available actions, this value will be disregarded.
    * The dropdown will be automatically locked while the from dropdown is unset.
    **/
    lockedTo: boolean;
    /**
    * Optional from label. Default is "From"
    **/
    fromLabel: string;
    /**
    * Optional to label. Default is "To"
    **/
    toLabel: string;
    /**
    * Values that are temporarily disabled due to the from selection.
    * Values that are always disabled should use the isSelectable property on the dropdown option.
    **/
    ineligibleToValues: string[];
    /**
    * Used with ineligibleToValues to explain why the option is not selectable.
    **/
    ineligibleMessage: string;
    /**
    * Emits when a new value is selected in either dropdown.
    **/
    selection: EventEmitter<FundingOptionsResult>;
    form: UntypedFormGroup;
    isMobile: boolean;
    private fromValue;
    private toValue;
    private lastResult;
    managedToGroups: TemplateGroup<TTo>[];
    constructor(fb: UntypedFormBuilder, windowService: WindowService, textService: TextService);
    ngOnChanges(changes: SimpleChanges): void;
    ngOnInit(): void;
    get lockedFromDropdown(): boolean;
    get lockedToDropdown(): boolean;
    private getInitialValue;
    fromChanged(fromValue: string): void;
    toChanged(toValue: string): void;
    private getMatchingOptionFromValue;
    private getObjectFromValue;
    private buildResult;
    private buildAndEmitResult;
    private buildManagedToGroups;
    validate(): FundingOptionsResult;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<FundingOptionsComponent<any, any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FundingOptionsComponent<any, any>, "ui-workflows-funding-options", never, { "fromGroups": { "alias": "fromGroups"; "required": false; }; "toGroups": { "alias": "toGroups"; "required": false; }; "fromActions": { "alias": "fromActions"; "required": false; }; "toActions": { "alias": "toActions"; "required": false; }; "initialFromValue": { "alias": "initialFromValue"; "required": false; }; "initialToValue": { "alias": "initialToValue"; "required": false; }; "lockedFrom": { "alias": "lockedFrom"; "required": false; }; "lockedTo": { "alias": "lockedTo"; "required": false; }; "fromLabel": { "alias": "fromLabel"; "required": false; }; "toLabel": { "alias": "toLabel"; "required": false; }; "ineligibleToValues": { "alias": "ineligibleToValues"; "required": false; }; "ineligibleMessage": { "alias": "ineligibleMessage"; "required": false; }; }, { "selection": "selection"; }, never, never, false, never>;
}

declare class NotesResult implements FormWorkflowResult {
    readonly isValid: boolean;
    notes: string;
    constructor(isValid: boolean, notes?: string);
}

declare class NotesComponent implements OnChanges, FormWorkflowComponent {
    formRenderer: FormRendererComponent;
    /**
    * The text area field to render inside form-renderer
    **/
    field: TextAreaField;
    /**
    * The e2e hook to pass into form-renderer
    **/
    e2e: string;
    formRows: FormRendererRow[];
    ngOnChanges(changes: SimpleChanges): void;
    validate(): NotesResult;
    static ɵfac: i0.ɵɵFactoryDeclaration<NotesComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NotesComponent, "ui-workflows-notes", never, { "field": { "alias": "field"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; }, {}, never, never, false, never>;
}

declare enum PaymentOptionType {
    EDITABLE = "EDITABLE",
    VARIABLE = "VARIABLE",
    FIXED = "FIXED",
    UNKNOWN = "UNKNOWN"
}

declare class PaymentOption {
    label: string;
    id: string;
    amount: number;
    type: PaymentOptionType;
    isDefault: boolean;
    tooltip?: string;
    subtextLines?: string[];
}

declare class PaymentRadioButtonOption {
    label: string;
    value: string;
    amount: number;
    ariaLabel: string;
    subtextLines: string[];
    amountIsEditable: boolean;
    amountIsVariable: boolean;
    amountIsUnknown: boolean;
    formattedAmount: string;
    message: string;
    messageTheme: string;
    tooltip: string;
    id: string;
    constructor(paymentOption: PaymentOption);
    clearMessage(): void;
}

declare class PaymentOptionsResult implements FormWorkflowResult {
    option: PaymentOption;
    amount: number;
    insufficientFunds: boolean;
    get isValid(): boolean;
}

declare class PaymentOptionsComponent extends BaseTextComponent implements OnChanges, FormWorkflowComponent {
    private fb;
    private modalService;
    private windowService;
    protected textService: TextService;
    mobileModal: TemplateRef<any>;
    /**
    * Current valid payment options
    **/
    paymentOptions: PaymentOption[];
    /**
    * Controls form validation. If provided, "insufficient funds" validation is triggered
    * for options/amounts that exceed the available funds specified.
    **/
    availableFunds: number;
    /**
    * Optional info message to display beneath the amount input (when no payment options are available) or beneath
    * the payment option radio buttons.
    **/
    infoMessage: string;
    /**
    * Set to true to lock every form field.
    **/
    locked: boolean;
    /**
    * The initial value of the editable amount field.
    * This works with both payment options and the amount-only form.
    **/
    initialAmountValue: number;
    /**
    * Set to true to enable the variable amount message for variable payment options.
    * Note: This message will not appear if the insufficient funds message is triggered via availableFunds input.
    **/
    showVariableAmountMessage: boolean;
    /**
    * Optional header that displays above payment option radio buttons. Default is "How much would you like to pay?"
    * Note: does not display in mobile.
    **/
    header: string;
    /**
    * Optional subheader that displays above payment option radio buttons and below the header.
    * Note: This supports html.
    **/
    subHeader: string;
    /**
    * Optional details that display above payment option radio buttons and below the subheader.
    * Note: This supports html.
    **/
    subHeaderDetails: string[];
    /**
    * Optional mobile button label, default value is 'Select a payment option'.
    **/
    mobilePaymentOptionLabel: string;
    /**
    *  Emitted when the option changes. Only emits if payment options are provided.
    **/
    optionChanged: EventEmitter<PaymentOption>;
    /**
    *  Emitted when the insufficient funds warning has been resolved. This only emits if the payment option
    *  workflow had been previously validated (ie: parent form submitted).
    **/
    insufficientFundsFixed: EventEmitter<void>;
    radioOptions: PaymentRadioButtonOption[];
    radioOptionsErrorMessage: string;
    mobileButtonForm: UntypedFormGroup;
    private mobileButtonAmount;
    mobileButtonErrorMessage: string;
    mobileButtonWarningMessage: string;
    mobileButtonInfoMessage: string;
    showAmountOnlyForm: boolean;
    amountOnlyForm: UntypedFormGroup;
    editableAmountForm: UntypedFormGroup;
    amountWarningMessage: string;
    private selectedPaymentOption;
    selectedPaymentOptionId: string;
    isMobile: boolean;
    hasSubHeaderContent: boolean;
    radioFieldId: string;
    workflowFormId: string;
    private insufficientFundsTriggered;
    constructor(fb: UntypedFormBuilder, modalService: ModalService, windowService: WindowService, textService: TextService);
    ngOnChanges(changes: SimpleChanges): void;
    private refreshVisibleForms;
    mobileWorkflowInitiated(): void;
    selectRadioButton(option: PaymentRadioButtonOption): void;
    private setSelectedRadioMessage;
    private amountExceedsAvailableFunds;
    submitModalWorkflow(): void;
    private selectedOptionIsValid;
    onModalClose(): void;
    private updateMobileButtonForm;
    private getPaymentOptionSummary;
    private resetForms;
    private setRadioOptions;
    private isValidPaymentOption;
    private get amountInputValidators();
    private amountInputInsufficientFundsValidator;
    private get mobileButtonValidators();
    private mobileButtonValidator;
    protected getDefaultText(): any;
    validate(): PaymentOptionsResult;
    private buildResult;
    private checkIfInsufficientFundsFixed;
    static ɵfac: i0.ɵɵFactoryDeclaration<PaymentOptionsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PaymentOptionsComponent, "ui-workflows-payment-options", never, { "paymentOptions": { "alias": "paymentOptions"; "required": false; }; "availableFunds": { "alias": "availableFunds"; "required": false; }; "infoMessage": { "alias": "infoMessage"; "required": false; }; "locked": { "alias": "locked"; "required": false; }; "initialAmountValue": { "alias": "initialAmountValue"; "required": false; }; "showVariableAmountMessage": { "alias": "showVariableAmountMessage"; "required": false; }; "header": { "alias": "header"; "required": false; }; "subHeader": { "alias": "subHeader"; "required": false; }; "subHeaderDetails": { "alias": "subHeaderDetails"; "required": false; }; "mobilePaymentOptionLabel": { "alias": "mobilePaymentOptionLabel"; "required": false; }; }, { "optionChanged": "optionChanged"; "insufficientFundsFixed": "insufficientFundsFixed"; }, never, never, false, never>;
}

declare class RadioButtonCardOption<T> {
    label: string;
    description: string;
    id: string;
    isDefault: boolean;
    content: T;
    badge?: BadgeModel;
    _hover?: boolean;
}

declare class RadioButtonCardsComponent<T> extends BaseTextComponent implements OnChanges, FormWorkflowComponent {
    protected textService: TextService;
    /**
    * Options eligible to be selected
    **/
    options: RadioButtonCardOption<T>[];
    /**
    * Optional info message to display beneath the cards.
    **/
    infoMessage: string;
    /**
    * Optional error message to display beneath the cards.
    * Default value is "Required"
    **/
    errorMessage: string;
    /**
    * Required. Label that displays above all card options.
    **/
    label: string;
    /**
    * Optional. When true, displays cards in 3 columns on desktop instead of 2.
    * Mobile view always uses 1 column. Default is false.
    **/
    useThreeColumns: boolean;
    /**
    * Optional template for displaying content below the option label.
    * Renders data from the content property per option.
    * Use "content" property for template binding.
    **/
    contentTemplate: TemplateRef<any>;
    /**
    *  Emitted when the selected option changes.
    **/
    optionChanged: EventEmitter<RadioButtonCardOption<T>>;
    private selectedOption;
    selectedOptionId: string;
    radioFieldId: string;
    radioOptions: RadioButtonCardOption<T>[];
    showErrorState: boolean;
    isMobile: boolean;
    constructor(textService: TextService, windowService: WindowService);
    ngOnChanges(changes: SimpleChanges): void;
    setSelectedOption(option: RadioButtonCardOption<T>): void;
    private clearSelectedOption;
    selectRadioButton(option: RadioButtonCardOption<T>): void;
    private resetForms;
    private setRadioOptions;
    protected getDefaultText(): any;
    validate(): FormWorkflowResult;
    static ɵfac: i0.ɵɵFactoryDeclaration<RadioButtonCardsComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<RadioButtonCardsComponent<any>, "ui-workflows-radio-button-cards", never, { "options": { "alias": "options"; "required": false; }; "infoMessage": { "alias": "infoMessage"; "required": false; }; "errorMessage": { "alias": "errorMessage"; "required": false; }; "label": { "alias": "label"; "required": false; }; "useThreeColumns": { "alias": "useThreeColumns"; "required": false; }; "contentTemplate": { "alias": "contentTemplate"; "required": false; }; }, { "optionChanged": "optionChanged"; }, never, never, false, never>;
}

declare class RadioButtonCardsResult<T> implements FormWorkflowResult {
    option: RadioButtonCardOption<T>;
    get isValid(): boolean;
}

declare enum RecurringEndingType {
    NEVER = "NEVER",
    AFTER_NUMBER = "AFTER_NUMBER",
    ON_DATE = "ON_DATE"
}

declare enum RecurringFallbackType {
    PRIOR_DAY = "PRIOR_DAY",
    NEXT_DAY = "NEXT_DAY"
}

declare class ScheduleOption {
    readonly frequency: string;
    fee: number;
    hideFeeAccount: boolean;
    icon: string;
    label: string;
    description: string;
    id: string;
    isDefault: boolean;
    get frequencyRequired(): boolean;
    get feeAccountRequired(): boolean;
    constructor(frequency?: string);
}

declare class ScheduleOptionsResult implements FormWorkflowResult {
    private requireFallback;
    option: ScheduleOption;
    feeAccount: any;
    frequency: FrequencyOption;
    startDate: string;
    startMonth: number;
    firstDay: number;
    secondDay: number;
    ending: RecurringEndingType;
    endingDate: string;
    endingNumber: number;
    fallback: RecurringFallbackType;
    constructor(requireFallback: boolean);
    get isValid(): boolean;
    areFrequencySelectionsValid(validateFallback: boolean): boolean;
    private isValidDateValue;
    private isValidEnding;
    private isValidFallback;
}

declare class ScheduleOptionsComponent extends BaseTextComponent implements OnChanges, FormWorkflowComponent {
    private fb;
    private modalService;
    private windowService;
    private readonly dateProvider;
    protected textService: TextService;
    scheduleForm: FormRendererComponent;
    frequencyForm: FormRendererComponent;
    fallbackForm: FormRendererComponent;
    frequencyModal: TemplateRef<any>;
    /**
    * Allowed schedule options to present in the schedule dropdown.
    * At least one must be provided. If only one is provided, it is visually hidden.
    **/
    scheduleOptions: ScheduleOption[];
    /**
    * Customizable label for schedule dropdown. Default is "Send".
    **/
    scheduleLabel: string;
    /**
    * Customizable tooltip for schedule dropdown. Default is blank (no tooltip).
    **/
    scheduleTooltip: string;
    /**
    * Allowed frequency options
    **/
    frequencyOptions: FrequencyOption[];
    /**
    * A warning message to display beneath the frequency dropdown.
    **/
    frequencyWarningMessage: string;
    /**
    * Allowed options for paying schedule fee
    **/
    feeAccountOptions: TemplateGroup<AccountTemplateData>[];
    /**
    * Set to true to lock every form field.
    **/
    locked: boolean;
    /**
    * Disables start date holidays
    **/
    startDateDisableHolidays: boolean;
    /**
    * Disables start date weekends
    **/
    startDateDisableWeekends: boolean;
    /**
    * The earliest possible start date.
    **/
    startDateMinDate: Date;
    /**
    * A success message to display beneath the start date.
    **/
    startDateSuccessMessage: string;
    /**
    * Optional messaging about the selected date.
    **/
    startDateSelectedDateText: string;
    /**
    * Controls optional messaging about lead days before or after the selected start date.
    **/
    startDateLeadDays: number;
    /**
    * Optional messaging about about lead days.
    **/
    startDateLeadDaysMessage: string;
    /**
    * Lead days by default are calculated before the selected date,
    * but can be enabled for after the selected date.
    **/
    leadDaysAreAfterSelectedDate: boolean;
    /**
    * Controls optional messaging about a marked date
    **/
    startDateMarkedDate: Date;
    /**
    * Optional messaging about a marked date.
    **/
    startDateMarkedDateText: string;
    /**
    * Control visibility of the start date option.
    * Only applied when the selected frequency is ONE_TIME_FUTURE.
    * Note: the result is considered invalid as no start date is selected.
    **/
    startDateHidden: boolean;
    /**
    * Array of Holidays used to prevent selection
    **/
    holidays: Holiday[];
    /**
    * Array of allowed RecurringEndingType. An empty array means all are valid.
    **/
    endingTypes: RecurringEndingType[];
    /**
    * The maximum number when RecurringEndingType AFTER_NUMBER is selected
    **/
    maxNumberRecurring: number;
    /**
    * Control visibility of the fallback options.
    **/
    showFallbackTypes: boolean;
    /**
    * The initial value of the frequency dropdown.
    **/
    initialFrequencyValue: string;
    /**
    * The initial value of the start date field.
    **/
    initialStartDateValue: string;
    /**
    * The initial value of the first day field (TWO_DAYS_A_MONTH only).
    **/
    initialFirstDayValue: number;
    /**
    * The initial value of the second day field (TWO_DAYS_A_MONTH only).
    **/
    initialSecondDayValue: number;
    /**
    * The initial value of the start month field (TWO_DAYS_A_MONTH only).
    **/
    initialStartMonthValue: number;
    /**
    * The initial value of the ending field.
    **/
    initialEndingValue: RecurringEndingType;
    /**
    * The initial value of the ending date field.
    **/
    initialEndingDateValue: string;
    /**
    * The initial value of the ending number field.
    **/
    initialEndingNumberValue: number;
    /**
    * The initial value of the fee account dropdown.
    **/
    initialFeeAccountValue: string;
    /**
    * The initial value of the recurring fallback radio buttons.
    **/
    initialFallbackValue: RecurringFallbackType;
    /**
    *  Emitted when the schedule changes.
    **/
    scheduleChanged: EventEmitter<ScheduleOption>;
    /**
    *  Emitted when the frequency changes.
    **/
    frequencyChanged: EventEmitter<FrequencyOption>;
    /**
    *  Emitted when the start date changes.
    **/
    startDateChanged: EventEmitter<string>;
    /**
    *  Emitted when the start date action is clicked.
    **/
    startDateActionButtonClicked: EventEmitter<void>;
    scheduleFormRows: FormRendererRow[];
    private selectedScheduleOption;
    private selectedFeeAccount;
    private scheduleDropdownField;
    private feeAccountDropdownField;
    showFrequencyForm: boolean;
    frequencyFormRows: FormRendererRow[];
    private selectedFrequencyOption;
    private frequencyDropdownField;
    private startDateField;
    private endingDropdownField;
    private endingNumberField;
    private endingDateField;
    private firstDayField;
    private firstDayValue;
    private secondDayField;
    private secondDayValue;
    private startMonthField;
    private startMonthValue;
    private twiceAMonthGroup;
    mobileFrequencyButtonForm: UntypedFormGroup;
    mobileFrequencyButtonErrorMessage: string;
    private hasOpenedMobileModal;
    private modalClosedBySubmission;
    fallbackFormRows: FormRendererRow[];
    private fallbackField;
    isMobile: boolean;
    constructor(fb: UntypedFormBuilder, modalService: ModalService, windowService: WindowService, dateProvider: DateProvider, textService: TextService);
    ngOnChanges(changes: SimpleChanges): void;
    private buildScheduleFormRows;
    private getInitialScheduleOption;
    private isValidScheduleOption;
    private getScheduleDropdownGroup;
    onScheduleFormSelection(event: FormRendererSelectionEvent): void;
    private onScheduleChanged;
    private buildFrequencyFormRows;
    private isValidFrequencyOption;
    private getInitialFrequencyOption;
    private getFrequencyDropdownOptions;
    private getTwiceAMonthFormRows;
    private getAllowedEndingTypes;
    private getEndingOptions;
    private updateStartDateValidation;
    private getMinStartDate;
    private updateEndingDateValidation;
    onFrequencyFormSelection(event: FormRendererSelectionEvent): void;
    private onFrequencyChanged;
    private setFrequencyFieldVisibility;
    private onEndingChanged;
    private onStartDateChanged;
    private onEndingDateChanged;
    private onFirstDayChanged;
    private calculateTwoDaysAMonthStartDate;
    private hideRecurringFields;
    private showRecurringFields;
    private showStartDateField;
    private emitStartDateActionButtonClick;
    private showTwiceAMonthFields;
    mobileWorkflowInitiated(): void;
    submitModalWorkflow(formGroup: UntypedFormGroup): void;
    onModalClose(): void;
    private updateMobileFrequencyButtonForm;
    private get mobileButtonValidators();
    private mobileButtonValidator;
    private buildFallbackFormRows;
    validate(): ScheduleOptionsResult;
    private buildResult;
    private get startDateIsCurrentlyHidden();
    private get selectedFrequencyHasRecurringFields();
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<ScheduleOptionsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ScheduleOptionsComponent, "ui-workflows-schedule-options", never, { "scheduleOptions": { "alias": "scheduleOptions"; "required": false; }; "scheduleLabel": { "alias": "scheduleLabel"; "required": false; }; "scheduleTooltip": { "alias": "scheduleTooltip"; "required": false; }; "frequencyOptions": { "alias": "frequencyOptions"; "required": false; }; "frequencyWarningMessage": { "alias": "frequencyWarningMessage"; "required": false; }; "feeAccountOptions": { "alias": "feeAccountOptions"; "required": false; }; "locked": { "alias": "locked"; "required": false; }; "startDateDisableHolidays": { "alias": "startDateDisableHolidays"; "required": false; }; "startDateDisableWeekends": { "alias": "startDateDisableWeekends"; "required": false; }; "startDateMinDate": { "alias": "startDateMinDate"; "required": false; }; "startDateSuccessMessage": { "alias": "startDateSuccessMessage"; "required": false; }; "startDateSelectedDateText": { "alias": "startDateSelectedDateText"; "required": false; }; "startDateLeadDays": { "alias": "startDateLeadDays"; "required": false; }; "startDateLeadDaysMessage": { "alias": "startDateLeadDaysMessage"; "required": false; }; "leadDaysAreAfterSelectedDate": { "alias": "leadDaysAreAfterSelectedDate"; "required": false; }; "startDateMarkedDate": { "alias": "startDateMarkedDate"; "required": false; }; "startDateMarkedDateText": { "alias": "startDateMarkedDateText"; "required": false; }; "startDateHidden": { "alias": "startDateHidden"; "required": false; }; "holidays": { "alias": "holidays"; "required": false; }; "endingTypes": { "alias": "endingTypes"; "required": false; }; "maxNumberRecurring": { "alias": "maxNumberRecurring"; "required": false; }; "showFallbackTypes": { "alias": "showFallbackTypes"; "required": false; }; "initialFrequencyValue": { "alias": "initialFrequencyValue"; "required": false; }; "initialStartDateValue": { "alias": "initialStartDateValue"; "required": false; }; "initialFirstDayValue": { "alias": "initialFirstDayValue"; "required": false; }; "initialSecondDayValue": { "alias": "initialSecondDayValue"; "required": false; }; "initialStartMonthValue": { "alias": "initialStartMonthValue"; "required": false; }; "initialEndingValue": { "alias": "initialEndingValue"; "required": false; }; "initialEndingDateValue": { "alias": "initialEndingDateValue"; "required": false; }; "initialEndingNumberValue": { "alias": "initialEndingNumberValue"; "required": false; }; "initialFeeAccountValue": { "alias": "initialFeeAccountValue"; "required": false; }; "initialFallbackValue": { "alias": "initialFallbackValue"; "required": false; }; }, { "scheduleChanged": "scheduleChanged"; "frequencyChanged": "frequencyChanged"; "startDateChanged": "startDateChanged"; "startDateActionButtonClicked": "startDateActionButtonClicked"; }, never, never, false, never>;
}

declare enum MicroappMenuType {
    SINGLE = "single",
    MULTI = "multi"
}

declare class MicroappComponent extends BaseTextComponent implements OnChanges, OnInit {
    private injector;
    private router;
    protected textService: TextService;
    /**
    * The ID of the microapp. Used for e2e hooks, and also to join mobile dashboard button links to their respective microapp.
    **/
    id: string;
    /**
    * The optional title of the microapp.
    **/
    title: string;
    /**
    * The optional subtitle of the microapp.
    **/
    subtitle: string;
    /**
    * Text of optional primary button.
    **/
    primaryButtonText: string;
    /**
    * Screen-reader label to apply to primary button for accessibility.
    *   Read instead of, or in addition to, to the primaryButtonText (depending on device).
    **/
    primaryButtonAriaLabel: string;
    /**
    * The url to navigate to on primary button click.
    **/
    primaryButtonUrl: string;
    /**
    * Query parameters for the primaryButtonUrl.
    **/
    primaryButtonUrlParams: Params;
    /**
    * If true, the primary button will be disabled, preventing clicks, navigation, and focus. Defaults to false.
    **/
    primaryButtonDisabled: boolean;
    /**
    * Primary button message to show when disabled, typically displays next to a spinner. If not set, normal button text will be shown.
    **/
    primaryButtonDisabledText: string;
    /**
    * If true, the primary button will show a spinner in the disabled state. Defaults to false.
    **/
    primaryButtonDisabledSpinner: boolean;
    /**
    * Text of optional additional button OR link.
    **/
    additionalButtonText: string;
    /**
    * Screen-reader label to apply to additional button for accessibility.
    *   Read instead of, or in addition to, to the additionalButtonText (depending on device).
    **/
    additionalButtonAriaLabel: string;
    /**
    * The url to navigate to on additional button click.
    **/
    additionalButtonUrl: string;
    /**
    * Query parameters for the additionalButtonUrl.
    **/
    additionalButtonUrlParams: Params;
    /**
    * Valid inputs are either 'link' or 'secondary'.
    * However, if layout is set to 'glass-chin', this theme is always 'secondary'.
    **/
    additionalButtonTheme: 'link' | 'secondary';
    /**
    * If true, the microapp will have a 'eye' toggle icon and 'drag' icon visible. Used for Dashboard's "edit mode." Defaults to false.
    **/
    editMode: boolean;
    /**
    * If true, the microapp's 'eye' toggle icon will show as enabled within "edit mode". Defaults to false.
    **/
    enabled: boolean;
    /**
    * If true, the content won't have built-in side padding. Defaults to false.
    **/
    noContentPadding: boolean;
    /**
    * If true, the content won't have built-in bottom padding. Defaults to false.
    **/
    noContentPaddingBottom: boolean;
    /**
    * If true, the microapp won't have any built-in padding at all. Useful when an image should fill the content edge-to-edge. Defaults to false.
    **/
    noPadding: boolean;
    /**
    * If true, a close button will show in the top right corner of the component. Defaults to false.
    **/
    showCloseButton: boolean;
    /**
    * The layout of the microapp. Default is the Dashboard style.
    **/
    layout: 'default' | 'glass-chin';
    /**
    * This optional input provides a way to inject a component into the microapp's content.
    **/
    component: Component;
    /**
    * This optional input provides a way to inject a "menu" component within the top right of the microapp.
    **/
    menuComponent: Component;
    /**
    * If the microapp content is injected, this input provides extra context.
    **/
    appContext: any[];
    /**
     * This will be passed to the microapp content component via input binding.
     */
    microappLocationContext: any;
    /**
    * Type of menu to show in microapp header. No menu will be shown if not defined.
    **/
    menuType: MicroappMenuType;
    /**
    * PickerOptions to be passed to the microapp menu
    **/
    menuOptions: PickerOption<string | number>[];
    /**
    * Initial value of the microapp menu
    **/
    menuValue: string | number | string[];
    /**
    * String label of the microapp menu, mainly for screen-readers
    **/
    menuLabel: string;
    /**
    * If there isn't a "primaryButtonUrl" supplied, this emits when the primary button is clicked.
    **/
    primaryButtonClicked: EventEmitter<void>;
    /**
    * If there isn't a "additionalButtonUrl" supplied, this emits when the additional button is clicked.
    **/
    additionalButtonClicked: EventEmitter<void>;
    /**
    * When the toggle button is clicked, emits the id of the microapp and whether it's enabled.
    **/
    toggleButtonClicked: EventEmitter<{
        id: string;
        enabled: boolean;
    }>;
    /**
    * Emits DOM Event when close button is clicked.
    **/
    closed: EventEmitter<any>;
    /**
    * Emits value when microapp menu is changed
    **/
    menuValueChange: EventEmitter<string | number | string[]>;
    appContextInjector: Injector;
    MicroappMenuType: typeof MicroappMenuType;
    menuAriaLabel: string;
    updatedPrimaryButtonAriaLabel: string;
    updatedAdditionalButtonAriaLabel: string;
    isGlassChinLayout: boolean;
    microappButtonUpdatesEnabled: boolean;
    constructor(injector: Injector, router: Router, textService: TextService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    onPrimaryButtonClick(): void;
    onAdditionalButtonClick(): void;
    editModeToggleClick(): void;
    close(event: Event): void;
    private setAriaLabels;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<MicroappComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MicroappComponent, "ui-workflows-microapp", never, { "id": { "alias": "id"; "required": false; }; "title": { "alias": "title"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "primaryButtonText": { "alias": "primaryButtonText"; "required": false; }; "primaryButtonAriaLabel": { "alias": "primaryButtonAriaLabel"; "required": false; }; "primaryButtonUrl": { "alias": "primaryButtonUrl"; "required": false; }; "primaryButtonUrlParams": { "alias": "primaryButtonUrlParams"; "required": false; }; "primaryButtonDisabled": { "alias": "primaryButtonDisabled"; "required": false; }; "primaryButtonDisabledText": { "alias": "primaryButtonDisabledText"; "required": false; }; "primaryButtonDisabledSpinner": { "alias": "primaryButtonDisabledSpinner"; "required": false; }; "additionalButtonText": { "alias": "additionalButtonText"; "required": false; }; "additionalButtonAriaLabel": { "alias": "additionalButtonAriaLabel"; "required": false; }; "additionalButtonUrl": { "alias": "additionalButtonUrl"; "required": false; }; "additionalButtonUrlParams": { "alias": "additionalButtonUrlParams"; "required": false; }; "additionalButtonTheme": { "alias": "additionalButtonTheme"; "required": false; }; "editMode": { "alias": "editMode"; "required": false; }; "enabled": { "alias": "enabled"; "required": false; }; "noContentPadding": { "alias": "noContentPadding"; "required": false; }; "noContentPaddingBottom": { "alias": "noContentPaddingBottom"; "required": false; }; "noPadding": { "alias": "noPadding"; "required": false; }; "showCloseButton": { "alias": "showCloseButton"; "required": false; }; "layout": { "alias": "layout"; "required": false; }; "component": { "alias": "component"; "required": false; }; "menuComponent": { "alias": "menuComponent"; "required": false; }; "appContext": { "alias": "appContext"; "required": false; }; "microappLocationContext": { "alias": "microappLocationContext"; "required": false; }; "menuType": { "alias": "menuType"; "required": false; }; "menuOptions": { "alias": "menuOptions"; "required": false; }; "menuValue": { "alias": "menuValue"; "required": false; }; "menuLabel": { "alias": "menuLabel"; "required": false; }; }, { "primaryButtonClicked": "primaryButtonClicked"; "additionalButtonClicked": "additionalButtonClicked"; "toggleButtonClicked": "toggleButtonClicked"; "closed": "closed"; "menuValueChange": "menuValueChange"; }, never, ["*"], false, never>;
}

declare class EndOfListComponent {
    /**
    * Required. The array of items (of class ListItem) to render in a list.
    **/
    items: ListItem[];
    /**
    * Required. The title text that displays when there are no items in the list.
    **/
    noListItemsTitleText: string;
    /**
    * Required. The subtitle text that displays when there are no items in the list.
    **/
    noListItemsSubtitleText: string;
    /**
    * Required. The subtitle text that displays when the end of the list has been reached.
    **/
    endOfListText: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<EndOfListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<EndOfListComponent, "ui-workflows-end-of-list", never, { "items": { "alias": "items"; "required": false; }; "noListItemsTitleText": { "alias": "noListItemsTitleText"; "required": false; }; "noListItemsSubtitleText": { "alias": "noListItemsSubtitleText"; "required": false; }; "endOfListText": { "alias": "endOfListText"; "required": false; }; }, {}, never, never, false, never>;
}

declare class ListTemplateComponent extends BaseDestroyComponent implements OnChanges {
    private windowService;
    /**
    * An optional input that specifies an avatar icon string corresponding to a Material Icon, a SVG icon, or a single char.
    **/
    avatarIcon: string;
    /**
    * An optional image URL input for an avatar.
    **/
    avatarImageUrl: string;
    /**
    * If the "avatarIcon" input is provided, this input controls the avatar's background color class. Any class tied to a background-color can be used here.
    **/
    avatarBackgroundClass: string;
    /**
    * If the "avatarIcon" input is provided, this input controls the avatar's icon color class. Any class tied to a font color can be used here.
    **/
    avatarIconColorClass: string;
    /**
    * If either input for "avatarIcon" or "avatarImageUrl" is provided, this input controls the shape of the avatar.
    **/
    avatarShape: 'circle' | 'rounded' | 'square';
    /**
    * Enable emoji support for icons. Checking for emojis is expensive, so only enable if needed.
    **/
    allowEmojis: boolean;
    /**
    * Enables "thread mode", which slightly changes the layout to better suit threaded conversations, which includes vertically centering the top left content.
    **/
    threadModeEnabled: boolean;
    /**
    * An optional text string intended to display in the top left corner
    **/
    topLeftText: string;
    /**
    * Optional class(es) to apply directly to top left element
    **/
    topLeftClass: string;
    /**
    * An optional icon to be shown to the right of the top left text. The given string must match a Material Icon, SVG Icon or emoji.
    **/
    topLeftIcon: string;
    /**
    * An optional text string to only be shown on screen readers within the top left corner
    **/
    topLeftScreenReaderText: string;
    /**
    * E2E testing - data-e2e attribute attached to top left element
    **/
    e2eTopLeft: string;
    /**
     * An optional text string to be shown inline with the top left text with tertiary font color.
     */
    topLeftAdditionalText: string;
    /**
    * An optional badge to be shown between the top left and top right corners
    **/
    topCenterBadge: BadgeModel;
    /**
    * An optional text string or number intended to display in the top right corner
    **/
    topRightText: string | number;
    /**
    * Optional class(es) to apply directly to top right element
    **/
    topRightClass: string;
    /**
    * An optional icon to be shown to the left of the top right text. The given string must match a Material Icon, SVG Icon or emoji.
    **/
    topRightIcon: string;
    /**
    * An optional badge to be shown to the right of the top right text
    **/
    topRightBadge: BadgeModel;
    /**
    * An optional text string to only be shown on screen readers within the top right corner
    **/
    topRightScreenReaderText: string;
    /**
    * E2E testing - data-e2e attribute attached to top right element
    **/
    e2eTopRight: string;
    /**
    * An optional text string intended to display in the bottom left corner
    **/
    bottomLeftText: string;
    /**
    * An optional HTML string intended to display in the bottom left corner
    **/
    bottomLeftHtml: string;
    /**
    * An array of details that display in a horizontal list separated by pipes in the bottom left corner.
    * Use the PipedDetail class to define each detail, which may have a message, icon, cssClass, NotificationTheme, and more.
    **/
    bottomLeftPipedDetails: PipedDetail[];
    /**
    * An optional text string to only be shown on screen readers within the bottom left corner
    **/
    bottomLeftScreenReaderText: string;
    /**
    * E2E testing - data-e2e attribute attached to bottom left element
    **/
    e2eBottomLeft: string;
    /**
    * An optional text string or number intended to display in the bottom right corner
    **/
    bottomRightText: string | number;
    /**
    * An array of details that display in a horizontal list separated by pipes in the bottom right corner.
    * Use the PipedDetail class to define each detail, which may have a message, icon, cssClass, NotificationTheme, and more.
    **/
    bottomRightPipedDetails: PipedDetail[];
    /**
    * An optional text string to only be shown on screen readers within the bottom right corner
    **/
    bottomRightScreenReaderText: string;
    /**
    * E2E testing - data-e2e attribute attached to bottom right element
    **/
    e2eBottomRight: string;
    /**
    * Size of the vertical spacing around the template.
    * Small/sm, Medium/md or Large/lg which each correspond to standard spacing variables. Defaults to small.
    **/
    verticalPaddingSize: 'sm' | 'md' | 'lg';
    isLowRes: boolean;
    isMobile: boolean;
    sanitizedBottomLeftHtml: string;
    constructor(windowService: WindowService);
    ngOnChanges(changes: SimpleChanges): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ListTemplateComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ListTemplateComponent, "ui-workflows-list-template", never, { "avatarIcon": { "alias": "avatarIcon"; "required": false; }; "avatarImageUrl": { "alias": "avatarImageUrl"; "required": false; }; "avatarBackgroundClass": { "alias": "avatarBackgroundClass"; "required": false; }; "avatarIconColorClass": { "alias": "avatarIconColorClass"; "required": false; }; "avatarShape": { "alias": "avatarShape"; "required": false; }; "allowEmojis": { "alias": "allowEmojis"; "required": false; }; "threadModeEnabled": { "alias": "threadModeEnabled"; "required": false; }; "topLeftText": { "alias": "topLeftText"; "required": false; }; "topLeftClass": { "alias": "topLeftClass"; "required": false; }; "topLeftIcon": { "alias": "topLeftIcon"; "required": false; }; "topLeftScreenReaderText": { "alias": "topLeftScreenReaderText"; "required": false; }; "e2eTopLeft": { "alias": "e2eTopLeft"; "required": false; }; "topLeftAdditionalText": { "alias": "topLeftAdditionalText"; "required": false; }; "topCenterBadge": { "alias": "topCenterBadge"; "required": false; }; "topRightText": { "alias": "topRightText"; "required": false; }; "topRightClass": { "alias": "topRightClass"; "required": false; }; "topRightIcon": { "alias": "topRightIcon"; "required": false; }; "topRightBadge": { "alias": "topRightBadge"; "required": false; }; "topRightScreenReaderText": { "alias": "topRightScreenReaderText"; "required": false; }; "e2eTopRight": { "alias": "e2eTopRight"; "required": false; }; "bottomLeftText": { "alias": "bottomLeftText"; "required": false; }; "bottomLeftHtml": { "alias": "bottomLeftHtml"; "required": false; }; "bottomLeftPipedDetails": { "alias": "bottomLeftPipedDetails"; "required": false; }; "bottomLeftScreenReaderText": { "alias": "bottomLeftScreenReaderText"; "required": false; }; "e2eBottomLeft": { "alias": "e2eBottomLeft"; "required": false; }; "bottomRightText": { "alias": "bottomRightText"; "required": false; }; "bottomRightPipedDetails": { "alias": "bottomRightPipedDetails"; "required": false; }; "bottomRightScreenReaderText": { "alias": "bottomRightScreenReaderText"; "required": false; }; "e2eBottomRight": { "alias": "e2eBottomRight"; "required": false; }; "verticalPaddingSize": { "alias": "verticalPaddingSize"; "required": false; }; }, {}, never, never, false, never>;
}

declare class UiWorkflowsModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UiWorkflowsModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UiWorkflowsModule, [typeof AddressVerificationModalComponent, typeof ChatMessageBodyComponent, typeof ChatMessageComponent, typeof ChatPageComponent, typeof ChatWindowComponent, typeof ChipEditorComponent, typeof ConfirmationModalComponent, typeof DataCardComponent, typeof EditLabelValueModalComponent, typeof EndOfListComponent, typeof FundingOptionsComponent, typeof ListComponent, typeof ListFormComponent, typeof MicroappComponent, typeof NotesComponent, typeof PaymentOptionsComponent, typeof RadioButtonCardsComponent, typeof ReasonModalComponent, typeof ScheduleOptionsComponent, typeof SearchSortFilterComponent, typeof TableComponent, typeof TableTemplatesDefinitionsComponent, typeof BulkActionsComponent, typeof ListTemplateComponent, typeof TableActionsComponent], [typeof i26.CommonModule, typeof i27.DragDropModule, typeof i28.FormsModule, typeof i29.NgbModule, typeof i28.ReactiveFormsModule, typeof i30.UiCoreModule, typeof i31.UiFormsModule], [typeof AddressVerificationModalComponent, typeof ChatMessageBodyComponent, typeof ChatMessageComponent, typeof ChatPageComponent, typeof ChatWindowComponent, typeof ChipEditorComponent, typeof ConfirmationModalComponent, typeof DataCardComponent, typeof EditLabelValueModalComponent, typeof FundingOptionsComponent, typeof ListComponent, typeof ListFormComponent, typeof MicroappComponent, typeof NotesComponent, typeof PaymentOptionsComponent, typeof RadioButtonCardsComponent, typeof ReasonModalComponent, typeof ScheduleOptionsComponent, typeof SearchSortFilterComponent, typeof TableComponent, typeof TableTemplatesDefinitionsComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UiWorkflowsModule>;
}

export { AddressVerificationModalComponent, BaseDataCardItem, BulkAction, BulkActionEvent, BulkActionsComponent, ChatMessage, ChatMessageAction, ChatMessageActionType, ChatMessageBodyComponent, ChatMessageComponent, ChatMessageDirection, ChatMessageReplyActionRole, ChatMessageSenderType, ChatPageAction, ChatPageComponent, ChatSession, ChatWindowComponent, ChatWindowMode, ChipEditorComponent, ColumnFilterList, ColumnFilterOption, ConfirmationModalComponent, ConfirmationModalEvent, DataCardComponent, DataCardDisplayItem, DataCardEditItem, DataCardItemGroup, DataCardModel, DataCardSensitiveItem, DateFilterType, EditLabelValueModalComponent, FrequencyOption, FrequencyType, FundingOptionsComponent, FundingOptionsResult, ListComponent, ListFormComponent, ListFormField, ListFormFieldType, ListFormItem, ListItem, MicroappComponent, MicroappMenuType, NotesComponent, NotesResult, PaymentOption, PaymentOptionType, PaymentOptionsComponent, PaymentOptionsResult, RadioButtonCardOption, RadioButtonCardsComponent, RadioButtonCardsResult, ReasonModalComponent, ReasonModalEvent, RecurringEndingType, RecurringFallbackType, ScheduleOption, ScheduleOptionsComponent, ScheduleOptionsResult, SearchSortFilter, SearchSortFilterComponent, TableAction, TableActionEvent, TableActionsComponent, TableBadgesContext, TableCellContent, TableColumn, TableComponent, TableFilter, TableFilterEvent, TableIconContext, TableRow, TableSortDirection, TableState, TableStateService, TableStickyColumnConfig, TableTemplateType, TableTemplateUtils, TableTemplatesDefinitionsComponent, TableTemplatesService, UiWorkflowsModule };
export type { ChatMessageActionClickEvent, DataCardItem };
//# sourceMappingURL=index.d.ts.map
