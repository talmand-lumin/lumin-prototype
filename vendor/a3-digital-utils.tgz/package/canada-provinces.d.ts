export interface CanadaProvinces {
    abbr: string;
    name: string;
}
export declare const CANADA_PROVINCES: CanadaProvinces[];
