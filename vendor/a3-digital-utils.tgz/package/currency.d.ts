export declare class Currency {
    name: string;
    alphaCode: string;
    numericCode?: string;
    flagEmoji?: string;
    symbol?: string;
}
