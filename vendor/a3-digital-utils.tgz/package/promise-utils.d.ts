export declare class PromiseUtils {
    static wait(milliseconds: number): Promise<void>;
}
