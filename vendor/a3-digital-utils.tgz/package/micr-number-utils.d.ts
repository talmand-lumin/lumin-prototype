import { CheckDigitAlgorithm } from './check-digit-algorithm.js';
export declare class MicrNumberUtils {
    static generateCheckDigit(micrNumber: string, algorithm?: CheckDigitAlgorithm): string;
    private static mod9Algorithm;
    private static luhnAlgorithm;
}
