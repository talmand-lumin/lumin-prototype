import { DescriptionValue } from './description-value.js';
export declare const STOP_PAYMENT_REASONS: DescriptionValue[];
