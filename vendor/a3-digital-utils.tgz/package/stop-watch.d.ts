export declare class StopWatch {
    private startTime;
    static createAndStart(): StopWatch;
    start(): void;
    stop(): number;
}
