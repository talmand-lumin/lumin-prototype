import { Country } from './countries.js';
import { Currency } from './currency.js';
import { PhoneParts } from './phone-parts.js';
export declare class CountryUtils {
    static readonly UNITED_STATES: Country;
    static readonly COUNTRIES_WITH_DIAL_CODES: Country[];
    private static readonly SORTED_DIAL_CODES;
    static getCountriesFromPhoneNumber(value: string): Country[];
    static sanitizePhoneNumber(value: string, allowInternational?: boolean): string;
    static sanitizeDomesticPhoneNumber(value: string): string;
    static isForeignPhoneNumber(value: string): boolean;
    private static getInternationalPhoneParts;
    static parsePhoneParts(phone: string, isPartialPhoneNumber?: boolean): PhoneParts;
    static sanitizePhoneParts(phoneParts: PhoneParts, allowInternational?: boolean): string;
    static parseAndSanitizePhoneParts(phone: string, allowInternational?: boolean): string;
    static getUniqueCurrenciesFromCountries(countries: Country[]): Currency[];
    static formattedCurrencyName(currency: Currency): string;
    static convertAlpha2ToAlpha3(alpha2: string): string;
    static convertAlpha3ToAlpha2(alpha3: string): string;
    static getFlagEmojiForPhoneNumber(phoneNumber: string): string;
}
