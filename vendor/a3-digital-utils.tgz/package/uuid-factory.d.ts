export declare class UuidFactory {
    create(): string;
}
