import { Currency } from './currency.js';
export declare const CURRENCIES: Currency[];
