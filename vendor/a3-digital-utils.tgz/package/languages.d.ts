export interface Language {
    code: string;
    name: string;
    nativeName?: string;
}
export declare class LanguageArray extends Array<Language> {
    readonly English: Language;
    constructor(languages: Language[], englishLanguage: Language);
}
export declare const LANGUAGE_CODES: {
    English: string;
    Spanish: string;
    Burmese: string;
};
export declare const LANGUAGES: LanguageArray;
export declare const LANGUAGE_WILDCARD = "*";
