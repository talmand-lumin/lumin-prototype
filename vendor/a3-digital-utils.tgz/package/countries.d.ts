export interface Country {
    name: string;
    alpha2: string;
    alpha3: string;
    m49: string;
    dialCode: string;
    areaCodes?: string[];
    currencyName: string;
    currencyAlphaCode: string;
    currencyNumericCode: string;
    isIban: boolean;
    flagEmoji: string;
    postalCodeRegex?: RegExp;
}
export declare const US_ALPHA2_CODE = "US";
export declare const DOMESTIC_DIAL_CODE = "1";
export declare const COUNTRIES: Country[];
