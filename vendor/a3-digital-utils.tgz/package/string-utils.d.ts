export declare class StringUtils {
    private static reRegExpChar;
    private static reHasRegExpChar;
    private static reHasEmoticonChar;
    private static reHasEmojiChar;
    private static reHasEmojiFlagChar;
    static escapeRegExp(val: string): string;
    static truncateString(str: string, maxLength: number): string;
    static right(str: string, numChrs: number): string;
    static truncateOrPadString(str: string, targetLength: number, padStr: string, padEnd: boolean): string;
    static padString(str: string, targetLength: number, padString: string, padEnd: boolean): string;
    static zeroPadNumber(num: number, targetLength: number): string;
    static trimLeadingZeros(str: string): string;
    static left(str: string, numChrs: number): string;
    static replaceAll(str: string, find: string, replace: string): string;
    static ensureIsString(str: any): string;
    static firstCharLowerCase(str: any): string;
    static redactCreditCardNumbers(text: string): string;
    static redactSsn(text: string): string;
    static stripNonNumeric(input: string, maxLength?: number): string;
    static toTitleCase(origText: string): string;
    static replaceSmartQuotes(str: string): string;
    static toCharArray(str: string): string[];
    static isString(val: any): boolean;
    static splitToChunks(input: string, maxChunkSize: number): string[];
    static toSSNFormat(input: string): string;
    static toEINFormat(input: string): string;
    static areEqualIgnoreCase(string1: string, string2: string): boolean;
    static containsEmojis(input: string): boolean;
    static stripNonAsciiAlpha(input: string, maxLength?: number): string;
    static areAsciiAlphaCharactersEqual(value1: string, value2: string, ignoreCase: boolean, requireAtleastOneAlphaCharacter?: boolean): boolean;
    static compareTwoStrings(first: string, second: string): number;
    static htmlEncode(html: string): string;
    private static readonly xmlMap;
    /**
    * Escapes XML special characters and truncates without breaking escape sequences.
    * Example:
    *   XmlUtils.safeTruncateAndEscape("Refund & Reimbursement", 20)
    *   → "Refund &amp; Reimbur"
    *   XmlUtils.safeTruncateAndEscape("Refund & Reimbursement", 10)
    *   → "Refund"
    *   (instead of "Refund &amp;" or broken "Refund &am")
    * Performance Note:
    * Uses a pre-defined `xmlMap` and processes input character-by-character
    * to avoid re-escaping the entire string in each loop iteration. This is
    * significantly faster than repeatedly calling xmlEscape() on substrings,
    * especially in large transaction exports.
    */
    static safeTruncateAndEscape(input: string, maxEscapedLength: number): string;
    static confirmOpenCharMatchesClosingChar(text: string, openChar: string, closeChar: string): boolean;
    static confirmEvenNumberOfChars(text: string, char: string): boolean;
}
