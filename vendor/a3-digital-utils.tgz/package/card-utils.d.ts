export declare class CardUtils {
    static isValidCardNumber(cardNum: string): boolean;
    static redactCardNumber(cardNum: string): string;
}
