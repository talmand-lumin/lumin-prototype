export declare class FieldChange {
    fieldName: string;
    oldValue: any;
    newValue: any;
}
