import * as i18 from '@angular/cdk/drag-drop';
import { CdkDragDrop, CdkDrag, CdkDropList, CdkDragMove } from '@angular/cdk/drag-drop';
import * as i0 from '@angular/core';
import { OnInit, EventEmitter, OnDestroy, OnChanges, TemplateRef, SimpleChanges, ElementRef, ChangeDetectorRef, NgZone, AfterViewInit, QueryList } from '@angular/core';
import * as i19 from '@angular/forms';
import { FormGroup, FormBuilder, AbstractControl, ControlContainer, ValidatorFn, UntypedFormGroup, UntypedFormBuilder } from '@angular/forms';
import * as i23 from '@a3-digital/ui-core';
import { BaseTextComponent, TextService, BadgeModel, PageActionItem, BreadcrumbItem, Action, WindowService, ButtonGridItem, BadgeTheme, InlineAction } from '@a3-digital/ui-core';
import * as i24 from '@a3-digital/ui-forms';
import { DropdownOption, ManagementEditor, ManagementEditorSelectionEvent, MultiSelectDropdownOption } from '@a3-digital/ui-forms';
import * as i20 from 'ngx-monaco-editor-v2';
import { DiffEditorModel } from 'ngx-monaco-editor-v2';
import * as i17 from '@angular/common';
import * as i21 from '@ng-bootstrap/ng-bootstrap';
import * as i22 from 'ngx-quill';

declare class DragAndDropListItem {
    actionButtonIcon?: string;
    actionButtonLabel?: string;
    actionDisabled?: boolean;
    badgeLabel?: string;
    hideRemoveButton?: boolean;
    label?: string;
    labelIcon?: string;
    message?: string;
    dropdownValue?: string | number;
    dropdownOptions: DropdownOption<number | string>[];
    formControlIndex: number;
    context?: any;
}

interface FormWorkflowResult {
    isValid: boolean;
}

declare class DragAndDropListResult implements FormWorkflowResult {
    readonly isValid: boolean;
    listItems: DragAndDropListItem[];
    constructor(isValid: boolean, listItems?: DragAndDropListItem[]);
}

declare class DragAndDropListComponent extends BaseTextComponent implements OnInit {
    private formBuilder;
    /**
    * Required. The array of items (of class DragAndDropListItem) to render in a list.
    **/
    listItems: DragAndDropListItem[];
    /**
    * Used to provide a prefix string for each list item. Defaults to 'Item'.
    **/
    listItemPrefix: string;
    /**
    * If a dropdown is needed, an array of DropdownOptions must be provided.
    **/
    dropdownOptions: DropdownOption<number | string>[];
    /**
    * If using a dropdown with the requirement that each list item has a unique value, set to this to true.
    **/
    dropdownOptionsShouldBeUnique: boolean;
    /**
    * If using a dropdown, this is the error message for the dropdown. Defaults to 'Required'.
    **/
    dropdownErrorMessage: string;
    /**
    * If newly added list items should be created with their action button disabled, set this to true.
    **/
    actionButtonDisabledForNewItems: boolean;
    /**
    * If a button to add extra list items is needed, this input is used to label and show it.
    **/
    addButtonLabel: string;
    /**
    * The maximum number of items allowed in the list. Once this max is reached, the "Add" button will be disabled.
    **/
    maxItemCount: number;
    /**
    * When enabled, all items will be allowed to be removed.
    **/
    allowAllItemRemoval: boolean;
    /**
    * An optional error message to show if there are no items in the list.
    **/
    noItemsErrorMessage: string;
    /**
    * Emits the row's DragAndDropListItem when an action button is clicked, which allows the parent component to handle the action.
    **/
    itemActionClicked: EventEmitter<DragAndDropListItem>;
    /**
    * Emits the index of the new DragAndDropListItem when the "Add" button is clicked.
    **/
    itemAdded: EventEmitter<number>;
    /**
    * Emits the index of the deleted DragAndDropListItem when the "Remove" button is clicked.
    **/
    itemRemoved: EventEmitter<number>;
    /**
    * Emits an object with a value and index of the changed DragAndDropListItem.
    **/
    itemDropdownChanged: EventEmitter<{
        value: number;
        index: number;
    }>;
    /**
    * Emits the array of DragAndDropListItems after the user drags and drops an item into a different position.
    **/
    itemMoved: EventEmitter<DragAndDropListItem[]>;
    actualMaxItemCount: number;
    currentDropdownIndex: number;
    form: FormGroup;
    constructor(formBuilder: FormBuilder, textService: TextService);
    ngOnInit(): void;
    onDropdownChange(value: number, index: number): void;
    addNewListItem(): void;
    removeListItem(item: DragAndDropListItem, index: number): void;
    onListItemAction(item: DragAndDropListItem): void;
    onListItemDrop(event: CdkDragDrop<string[]>): void;
    validate(): DragAndDropListResult;
    private recalculateDropdowns;
    private getDropdownOptions;
    private getUniqueListItemDropdownOptions;
    private setActualMaxItemCount;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<DragAndDropListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DragAndDropListComponent, "ui-management-drag-and-drop-list", never, { "listItems": { "alias": "listItems"; "required": false; }; "listItemPrefix": { "alias": "listItemPrefix"; "required": false; }; "dropdownOptions": { "alias": "dropdownOptions"; "required": false; }; "dropdownOptionsShouldBeUnique": { "alias": "dropdownOptionsShouldBeUnique"; "required": false; }; "dropdownErrorMessage": { "alias": "dropdownErrorMessage"; "required": false; }; "actionButtonDisabledForNewItems": { "alias": "actionButtonDisabledForNewItems"; "required": false; }; "addButtonLabel": { "alias": "addButtonLabel"; "required": false; }; "maxItemCount": { "alias": "maxItemCount"; "required": false; }; "allowAllItemRemoval": { "alias": "allowAllItemRemoval"; "required": false; }; "noItemsErrorMessage": { "alias": "noItemsErrorMessage"; "required": false; }; }, { "itemActionClicked": "itemActionClicked"; "itemAdded": "itemAdded"; "itemRemoved": "itemRemoved"; "itemDropdownChanged": "itemDropdownChanged"; "itemMoved": "itemMoved"; }, never, never, false, never>;
}

declare class HeaderComponent {
    /**
    * Required. Title text
    **/
    title: string;
    /**
    * Optional. Subtitle text that displays in-line, to the right of the title
    **/
    subtitle: string;
    /**
    * Optional. Array of badges (max of 5) to be displayed in-line with the title text.
    **/
    badges: BadgeModel[];
    /**
    * Optional. Description text that displays below the title.
    * Allows rich text html.
    **/
    description: string;
    /**
    * Optional. Array of Page Action Items
    **/
    pageActions: PageActionItem[];
    /**
    * Optional. Sets the page actions more menu button icon. Defaults to three vertical dots.
    **/
    pageActionsMenuIcon: string;
    /**
    * Optional. Sets the page actions more menu button text. Defaults to 'More'.
    **/
    pageActionsMenuText: string;
    /**
    * Optional. When true and there are 3 or more page actions, two of the actions will show outside the More dropdown menu.
    **/
    showTwoActionsOutsideMenu: boolean;
    /**
    * Optional. Array of Breadcrumb Items
    **/
    breadcrumbs: BreadcrumbItem[];
    /**
    * Optional. If set, a back button will display instead of breadcrumbs.
    **/
    backButtonUrl: string;
    /**
    * Optional. The text to display in the back button. Defaults to empty string.
    **/
    backButtonText: string;
    /**
    * Optional. A string corresponding to a Material Icon, a SVG icon, or a single char for the header icon.
    **/
    headerIcon: string;
    /**
    * Optional. The background class used to control the color of the header icon.
    **/
    headerIconBackgroundClass: string;
    /**
    * Optional. String to define a border around the header icon.
    **/
    headerIconBorderColor: string;
    /**
    * Optional. The class used to control the color of the header icon.
    **/
    headerIconColorClass: string;
    /**
    * Optional. Shape of the header icon.
    **/
    headerIconShape: 'circle' | 'rounded' | 'square';
    /**
    * Emitted when the back button is clicked.
    * This is only the case when backButtonUrl is not provided and therefore the back button is a true button.
    **/
    backButtonClicked: EventEmitter<boolean>;
    onBackButtonClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<HeaderComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HeaderComponent, "ui-management-header", never, { "title": { "alias": "title"; "required": false; }; "subtitle": { "alias": "subtitle"; "required": false; }; "badges": { "alias": "badges"; "required": false; }; "description": { "alias": "description"; "required": false; }; "pageActions": { "alias": "pageActions"; "required": false; }; "pageActionsMenuIcon": { "alias": "pageActionsMenuIcon"; "required": false; }; "pageActionsMenuText": { "alias": "pageActionsMenuText"; "required": false; }; "showTwoActionsOutsideMenu": { "alias": "showTwoActionsOutsideMenu"; "required": false; }; "breadcrumbs": { "alias": "breadcrumbs"; "required": false; }; "backButtonUrl": { "alias": "backButtonUrl"; "required": false; }; "backButtonText": { "alias": "backButtonText"; "required": false; }; "headerIcon": { "alias": "headerIcon"; "required": false; }; "headerIconBackgroundClass": { "alias": "headerIconBackgroundClass"; "required": false; }; "headerIconBorderColor": { "alias": "headerIconBorderColor"; "required": false; }; "headerIconColorClass": { "alias": "headerIconColorClass"; "required": false; }; "headerIconShape": { "alias": "headerIconShape"; "required": false; }; }, { "backButtonClicked": "backButtonClicked"; }, never, never, false, never>;
}

declare class HtmlEditorAction implements Action {
    text: string;
    action: () => void | Promise<void>;
    icon?: string;
    id?: string;
    e2e?: string;
    disabled?: boolean;
    disabledMessage?: string;
    showSpinner?: boolean;
    /**
     * If true, the html-editor will automatically show a loading overlay
     * when this action is triggered. The overlay will hide when the Promise resolves/rejects.
     * Note: Only works with Promise-based actions. Synchronous actions are ignored to avoid flicker.
     */
    showLoadingOverlay?: boolean;
}

declare abstract class BaseEditorComponent<T> extends BaseTextComponent implements ManagementEditor<T>, OnInit, OnDestroy {
    private controlContainer?;
    readonly mimicFormField = true;
    readonly managementEditor = true;
    controlTouched: boolean;
    controlInvalid: boolean;
    controlValid: boolean;
    /**
    * Displays a success themed message
    **/
    successMessage: string;
    /**
    * Displays an info themed message
    **/
    infoMessage: string;
    /**
    * Displays a warning themed message
    **/
    warningMessage: string;
    /**
    * Displays when the field is invalid
    **/
    errorMessage: string;
    get lockedMessage(): string;
    /**
    * Displays when the field is locked
    *  - has a default value that always displays for locked fields
    *  - accepts strings or boolean false - if you don't want any message displayed for a locked field, set this to false - `field.lockedMessage: false`
    **/
    set lockedMessage(value: string);
    /**
    * Required. The label for the form field
    **/
    label: string;
    /**
    * Can be used to visually hide the label. Label should always be provided, and hidden if undesired
    **/
    hideLabel: boolean;
    /**
    * Provides a unique name for the field used by Angular reactive forms.
    * Is used by some form field implementations to access the FormControl.
    * It is used to generate e2e attributes if e2e attribute is not provided.
    **/
    controlName: string;
    /**
    * Allows for a custom e2e prefix instead of using the form control name.
    **/
    e2e: string;
    /**
    * Specifies whether or not the field should be read-only. Locked fields cannot be modified by the user.
    **/
    locked: boolean;
    /**
    * Content to display in the tooltip popover
    **/
    tooltip: string;
    /**
    * Direction to place the tooltip popover.
    * "auto" (default) will attempt to place the popover where it can be seen (based on container/window bounds)
    * See ng-bootstrap documentation for details - type: Placement
    **/
    tooltipPlacement: 'auto' | 'top' | 'top-left' | 'top-right' | 'bottom' | 'bottom-left' | 'bottom-right' | 'left' | 'left-top' | 'left-bottom' | 'right' | 'right-top' | 'right-bottom';
    /**
    * Emits the new value when the value changes.
    **/
    change: EventEmitter<T>;
    private _control;
    protected get control(): AbstractControl;
    protected get value(): T;
    get showControlInvalid(): boolean;
    get required(): boolean;
    private _lockedMessage;
    baseText: any;
    readonly fieldId: string;
    readonly labelId: string;
    e2ePrefix: string;
    e2eField: string;
    private appliedValidators;
    private hasBeenInitialized;
    customErrorMessage: string;
    protected readonly errorMessageMap: Map<string, string>;
    constructor(textService: TextService, textConfigKey: string, controlContainer?: ControlContainer);
    ngOnInit(): void;
    ngOnDestroy(): void;
    protected updateValidators(source: 'onDestroy' | 'onChanges' | 'onInit', onChangesUpdate?: boolean): void;
    private setValidators;
    private removeValidators;
    private validatorsChanged;
    private setE2EPrefix;
    private mergeBaseText;
    private getLockedMessage;
    protected onValueChange(value: T): void;
    protected getValidators(): ValidatorFn[];
    protected getDefaultBaseText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<BaseEditorComponent<any>, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<BaseEditorComponent<any>, never, never, { "successMessage": { "alias": "successMessage"; "required": false; }; "infoMessage": { "alias": "infoMessage"; "required": false; }; "warningMessage": { "alias": "warningMessage"; "required": false; }; "errorMessage": { "alias": "errorMessage"; "required": false; }; "lockedMessage": { "alias": "lockedMessage"; "required": false; }; "label": { "alias": "label"; "required": false; }; "hideLabel": { "alias": "hideLabel"; "required": false; }; "controlName": { "alias": "controlName"; "required": false; }; "e2e": { "alias": "e2e"; "required": false; }; "locked": { "alias": "locked"; "required": false; }; "tooltip": { "alias": "tooltip"; "required": false; }; "tooltipPlacement": { "alias": "tooltipPlacement"; "required": false; }; }, { "change": "change"; }, never, never, true, never>;
}

declare class HtmlEditorComponent extends BaseEditorComponent<string> implements OnChanges {
    private textService;
    /**
    * If enabled, a button will be displayed to allow the user to insert videos.
    **/
    allowVideos: boolean;
    /**
    * By default, run the DOM sanitizer on html content. If you trust the content, you can disable this.
    **/
    sanitize: boolean;
    /**
    * If true, this takes over the 'info', 'success' and 'warning' messages,
    * so don't enable this if you need any of those messages to display.
    **/
    showCharactersRemaining: boolean;
    /**
    * The maximum amount of character input allowed in the text field.
    **/
    maxLength: number;
    /**
    * Optional. Actions to render in the toolbar.
    **/
    actions: HtmlEditorAction[];
    /**
    * Optional. A custom template to render in the footer of the editor in place of the actions.
    * When provided, this template takes precedence over the actions input.
    **/
    footerTemplate: TemplateRef<void> | null;
    /**
    * Optional. Sets the page actions more menu button icon. Defaults to three vertical dots.
    **/
    pageActionsMenuIcon: string;
    /**
    * Optional. The message to display in the loading overlay. 40 character limit for messages.
    **/
    loadingOverlayMessage: string;
    /**
    * Optional. The size of the spinner in the loading overlay.
    **/
    loadingOverlaySpinnerSize: 'sm' | 'md';
    /**
    * Optional. Sets the page actions more menu button text. Defaults to 'More'.
    **/
    pageActionsMenuText: string;
    /**
    * Optional. Toggle the loading overlay externally. When using the actions input with
    * showLoadingOverlay=true, this is also set automatically by the editor.
    **/
    isLoading: boolean;
    /**
     * Optional. Event that emits the currently selected text in the editor whenever the selection changes.
     * Emits an object containing both the plain text and the HTML content of the selection.
     */
    textSelection: EventEmitter<ManagementEditorSelectionEvent>;
    /**
     * (Internal use only - Form Renderer uses this to listen for selection events, all other use-cases should use the textSelection output)
     * Accepts a function that is called with the currently selected text in the editor whenever the selection changes.
     * Emits both the plain text and the HTML content of the selection.
     */
    _textSelected: ((event: ManagementEditorSelectionEvent) => void) | null;
    hasActions: boolean;
    pageActions: PageActionItem[];
    constructor(textService: TextService, controlContainer: ControlContainer);
    ngOnChanges(changes: SimpleChanges): void;
    private setMaxLengthErrorMessage;
    private wrapActionWithLoadingOverlay;
    onBlur(): void;
    onSelectionChanged(event: any): void;
    onEditorCreated(editor: any): void;
    protected onValueChange(value: string): void;
    private updateCharactersRemaining;
    protected getValidators(): ValidatorFn[];
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<HtmlEditorComponent, [null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<HtmlEditorComponent, "ui-management-html-editor", never, { "allowVideos": { "alias": "allowVideos"; "required": false; }; "sanitize": { "alias": "sanitize"; "required": false; }; "showCharactersRemaining": { "alias": "showCharactersRemaining"; "required": false; }; "maxLength": { "alias": "maxLength"; "required": false; }; "actions": { "alias": "actions"; "required": false; }; "footerTemplate": { "alias": "footerTemplate"; "required": false; }; "pageActionsMenuIcon": { "alias": "pageActionsMenuIcon"; "required": false; }; "loadingOverlayMessage": { "alias": "loadingOverlayMessage"; "required": false; }; "loadingOverlaySpinnerSize": { "alias": "loadingOverlaySpinnerSize"; "required": false; }; "pageActionsMenuText": { "alias": "pageActionsMenuText"; "required": false; }; "isLoading": { "alias": "isLoading"; "required": false; }; "_textSelected": { "alias": "_textSelected"; "required": false; }; }, { "textSelection": "textSelection"; }, never, never, false, never>;
}

declare class JsonDiffComponent extends BaseTextComponent implements OnChanges {
    /**
    * JSON object data shown in the previous/first/left pane
    **/
    previousData: object;
    /**
    * JSON object data to be diffed against & shown in the current/second/right pane
    **/
    currentData: object;
    /**
    * String label of previous/first/left diff pane
    **/
    previousDiffTitle: string;
    /**
    * String label of current/second/right diff pane
    **/
    currentDiffTitle: string;
    /**
    * Height of diff-view - requires a fixed height for the editor to measure & size-to, minimum 200
    **/
    height: number;
    previousDiffData: DiffEditorModel;
    currentDiffData: DiffEditorModel;
    diffOptions: any;
    constructor(textService: TextService);
    ngOnChanges(): void;
    buildMonacoDiffModel(value: any): DiffEditorModel;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<JsonDiffComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<JsonDiffComponent, "ui-management-json-diff", never, { "previousData": { "alias": "previousData"; "required": false; }; "currentData": { "alias": "currentData"; "required": false; }; "previousDiffTitle": { "alias": "previousDiffTitle"; "required": false; }; "currentDiffTitle": { "alias": "currentDiffTitle"; "required": false; }; "height": { "alias": "height"; "required": false; }; }, {}, never, never, false, never>;
}

declare class JsonEditorComponent extends BaseEditorComponent<string> implements OnChanges {
    resizeContainer: ElementRef;
    /**
    * JSON object data to display, mostly used for read-only/locked as editor data should be defined in form
    **/
    data: object;
    /**
    * Height of editor - requires a fixed height for the editor to measure & size-to, minimum 100
    **/
    height: number;
    /**
    * Display editor as read-only initially, but allow edit on button click
    **/
    showEditToggle: boolean;
    /**
    * When used as part of a form, this will enforce the JSON value is an array of strings
    **/
    stringArrayOnly: boolean;
    editorOptions: any;
    readOnly: boolean;
    readOnlyValue: string;
    heightStyles: {};
    initialHeight: string;
    readonly minHeight: string;
    private valueBeforeEdit;
    private monacoEditor;
    private contentChangeDisposable;
    hasMountedEditor: boolean;
    constructor(textService: TextService, controlContainer: ControlContainer);
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    private setInitialHeight;
    edit(): void;
    cancel(): void;
    onMonacoInit(editor: any): void;
    ngOnDestroy(): void;
    private setReadonlyFlag;
    private setReadonlyValue;
    protected onValueChange(value: string): void;
    protected getValidators(): ValidatorFn[];
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<JsonEditorComponent, [null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<JsonEditorComponent, "ui-management-json-editor", never, { "data": { "alias": "data"; "required": false; }; "height": { "alias": "height"; "required": false; }; "showEditToggle": { "alias": "showEditToggle"; "required": false; }; "stringArrayOnly": { "alias": "stringArrayOnly"; "required": false; }; }, {}, never, never, false, never>;
}

declare class MarkdownEditorComponent extends BaseEditorComponent<string> implements OnChanges {
    private textService;
    resizeContainer: ElementRef;
    /**
    * Height of editor - requires a fixed height for the editor to measure & size-to, minimum 100
    **/
    height: number;
    /**
    * Display editor as read-only initially, but allow edit on button click
    **/
    showEditToggle: boolean;
    editorOptions: any;
    readOnly: boolean;
    readOnlyValue: string;
    heightStyles: {};
    initialHeight: string;
    readonly minHeight: string;
    constructor(textService: TextService, controlContainer: ControlContainer);
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    private setInitialHeight;
    edit(): void;
    private setReadonlyFlag;
    private setReadonlyValue;
    protected onValueChange(value: string): void;
    protected getValidators(): ValidatorFn[];
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<MarkdownEditorComponent, [null, { optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<MarkdownEditorComponent, "ui-management-markdown-editor", never, { "height": { "alias": "height"; "required": false; }; "showEditToggle": { "alias": "showEditToggle"; "required": false; }; }, {}, never, never, false, never>;
}

declare class PanelListItem {
    data: any;
    id: string;
    constructor(data: any);
    static fromObject(data: any): PanelListItem;
}

declare class PanelListComponent {
    /**
    * Header at the top of the list.
    **/
    header: string;
    /**
    * Optional. When provided, an icon button will be rendered in the top right corner of the card.
    **/
    headerIcon: string;
    /**
    * Required if headerIcon is provided. The label for the header icon button.
    **/
    headerIconLabel: string;
    /**
    * Subheader at the top of the list.
    **/
    subheader: string;
    /**
    * Each item shown in the panel.
    **/
    items: PanelListItem[];
    /**
    * Required. The generic template to render for each item. Use the "data" property on each PanelListItem to pass data.
    **/
    itemTemplate: TemplateRef<any>;
    /**
    * Emits when the header icon is clicked.
    **/
    headerIconClicked: EventEmitter<void>;
    e2ePrefix: string;
    onHeaderIconClick(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<PanelListComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<PanelListComponent, "ui-management-panel-list", never, { "header": { "alias": "header"; "required": false; }; "headerIcon": { "alias": "headerIcon"; "required": false; }; "headerIconLabel": { "alias": "headerIconLabel"; "required": false; }; "subheader": { "alias": "subheader"; "required": false; }; "items": { "alias": "items"; "required": false; }; "itemTemplate": { "alias": "itemTemplate"; "required": false; }; }, { "headerIconClicked": "headerIconClicked"; }, never, never, false, never>;
}

declare class SearchBarComponent extends BaseTextComponent {
    /**
    * Set the value externally.
    **/
    value: string;
    /**
    * The maximum amount of character input allowed.
    **/
    maxLength: number;
    /**
    * Custom placeholder text that appears when no value is entered.
    * Default placeholder text is "Search"
    **/
    placeholder: string;
    /**
    * Set to true to automatically focus the search input after the component is initialized. Defaults to false.
    **/
    autoFocus: boolean;
    /**
    * Customizable text for Search button
    **/
    searchButtonText: string;
    /**
    * Customizable label for the searchByText
    **/
    searchByLabel: string;
    /**
    * Customizable text to display next to the "Search By:" label
    **/
    searchByText: string;
    /**
    * Set to true to set the loading state (if true, component is readonly & shows a spinner)
    **/
    loading: boolean;
    /**
    * Customizable input id
    **/
    inputId: string;
    /**
    * Emits when the search button is clicked
    **/
    searchSubmitted: EventEmitter<string>;
    constructor(textService: TextService);
    search(): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<SearchBarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SearchBarComponent, "ui-management-search-bar", never, { "value": { "alias": "value"; "required": false; }; "maxLength": { "alias": "maxLength"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "autoFocus": { "alias": "autoFocus"; "required": false; }; "searchButtonText": { "alias": "searchButtonText"; "required": false; }; "searchByLabel": { "alias": "searchByLabel"; "required": false; }; "searchByText": { "alias": "searchByText"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; "inputId": { "alias": "inputId"; "required": false; }; }, { "searchSubmitted": "searchSubmitted"; }, never, never, false, never>;
}

declare class TargetCondition {
    id: string;
    leftOperand: string;
    operator: ConditionOperator;
    rightOperand: string;
}
declare enum ConditionOperator {
    IS = "IS",
    IS_NOT = "IS_NOT",
    OVER = "OVER",
    UNDER = "UNDER",
    INCLUDES = "INCLUDES",
    DOES_NOT_INCLUDE = "DOES_NOT_INCLUDE"
}

declare class TargetConditionGroup {
    conditions: (TargetCondition | TargetConditionGroup)[];
    groupOperator: TargetGroupOperator;
    id: string;
}
declare enum TargetGroupOperator {
    AND = "AND",
    OR = "OR"
}

declare class TargetGroupData {
    condition?: TargetCondition;
    operator?: TargetGroupOperator;
    groupId: string;
}

declare class TargetOperatorOption {
    label: string;
    value: ConditionOperator | string;
}

declare class TargetOption {
    label: string;
    value: string;
}

declare class TargetWorkflowOptions {
    label: string;
    subject: string;
    operators: Array<TargetOperatorOption | ConditionOperator>;
    valueLabel?: string;
    valueOptions?: TargetOption[] | string[];
    valueDropdownOptions?: DropdownOption<string>[];
    valueType?: ConditionValueType;
}
declare enum ConditionValueType {
    NONE = "none",
    NUMBER = "number",
    SELECT = "select",
    MULTISELECT = "multiselect",
    STRING = "string",
    DATE = "date",
    CURRENCY = "currency"
}

declare class TargetConditionComponent extends BaseTextComponent implements OnChanges {
    protected textService: TextService;
    private changeDetector;
    private fb;
    private ngZone;
    private windowService;
    subjectDropdown: ElementRef;
    ruleDropdown: ElementRef;
    valueInput: ElementRef;
    deleteDiv: ElementRef;
    condition: TargetCondition;
    groupId: string;
    subjectDropdownOptions: DropdownOption<string>[];
    targetingOptions: TargetWorkflowOptions[];
    locked: boolean;
    groupConditionDeleted: EventEmitter<TargetGroupData>;
    groupConditionUpdated: EventEmitter<TargetGroupData>;
    form: UntypedFormGroup;
    isMobile: boolean;
    isMultiValueRule: boolean;
    operatorDropdownOptions: DropdownOption<string>[];
    valueLabel: string;
    valueType: ConditionValueType;
    valueHelpText: string;
    valueDropdownOptions: DropdownOption<string>[];
    valueMultiSelectOptions: MultiSelectDropdownOption[];
    ConditionValueType: typeof ConditionValueType;
    private multiValueOperators;
    constructor(textService: TextService, changeDetector: ChangeDetectorRef, fb: UntypedFormBuilder, ngZone: NgZone, windowService: WindowService);
    ngOnInit(): void;
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    isValid(): boolean;
    validate(): any;
    private setSpacing;
    private getFormSpacingElements;
    private onSubjectChanged;
    private onRuleChanged;
    private onValueChanged;
    onDeleteCondition(): void;
    private onConditionUpdated;
    private getTargetWorkflowOption;
    private getOperatorOptions;
    private setupValueField;
    private toMultiSelectOptions;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<TargetConditionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TargetConditionComponent, "ui-management-target-condition", never, { "condition": { "alias": "condition"; "required": false; }; "groupId": { "alias": "groupId"; "required": false; }; "subjectDropdownOptions": { "alias": "subjectDropdownOptions"; "required": false; }; "targetingOptions": { "alias": "targetingOptions"; "required": false; }; "locked": { "alias": "locked"; "required": false; }; }, { "groupConditionDeleted": "groupConditionDeleted"; "groupConditionUpdated": "groupConditionUpdated"; }, never, never, false, never>;
}

declare class TargetOperatorComponent {
    disabled: boolean;
    locked: boolean;
    andLabel: string;
    orLabel: string;
    value: TargetGroupOperator;
    valueChange: EventEmitter<TargetGroupOperator>;
    controlId: string;
    readonly andValue = TargetGroupOperator.AND;
    readonly orValue = TargetGroupOperator.OR;
    constructor();
    changeValue(value: TargetGroupOperator): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TargetOperatorComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TargetOperatorComponent, "ui-management-target-operator", never, { "disabled": { "alias": "disabled"; "required": false; }; "locked": { "alias": "locked"; "required": false; }; "andLabel": { "alias": "andLabel"; "required": false; }; "orLabel": { "alias": "orLabel"; "required": false; }; "value": { "alias": "value"; "required": false; }; }, { "valueChange": "valueChange"; }, never, never, false, never>;
}

declare class TargetResult implements FormWorkflowResult {
    readonly isValid: boolean;
    conditionGroup: TargetConditionGroup | TargetCondition;
    constructor(isValid: boolean, conditionGroup: TargetConditionGroup | TargetCondition);
}

declare class TargetingComponent extends BaseTextComponent implements AfterViewInit, OnChanges {
    protected textService: TextService;
    private changeDetector;
    groupOperator: TargetOperatorComponent;
    targetConditions: QueryList<TargetConditionComponent>;
    targetSubgroups: QueryList<TargetingComponent>;
    /**
    * Array of TargetWorkflowOptions to define available conditions & rules, text & options
    */
    targetingOptions: TargetWorkflowOptions[];
    /**
    * Targeted workflow data
    **/
    conditionGroup: TargetConditionGroup;
    /**
    * Specifies whether or not the component should be read-only. Locked fields cannot be modified by the user.
    **/
    locked: boolean;
    /**
    * emits full conditionGroup object on any change
    **/
    conditionGroupChange: EventEmitter<TargetConditionGroup>;
    /**
    * internal Inputs & Outputs
    **/
    _isSubGroup: boolean;
    _subjectDropdownOptions: DropdownOption<string>[];
    groupDeleted: EventEmitter<string>;
    groupConditionDeleted: EventEmitter<TargetGroupData>;
    groupConditionUpdated: EventEmitter<TargetGroupData>;
    id: string;
    constructor(textService: TextService, changeDetector: ChangeDetectorRef);
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterViewInit(): void;
    validate(): TargetResult;
    createConditionGroup(): void;
    addCondition(groupId: string): void;
    addGroup(): void;
    deleteGroup(groupId: string): void;
    deleteGroupCondition(cData: TargetGroupData): void;
    updateGroupCondition(cData: TargetGroupData): void;
    updateGroupOperator(operator: TargetGroupOperator): void;
    private getConditionGroup;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<TargetingComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TargetingComponent, "ui-management-targeting", never, { "targetingOptions": { "alias": "targetingOptions"; "required": false; }; "conditionGroup": { "alias": "conditionGroup"; "required": false; }; "locked": { "alias": "locked"; "required": false; }; "_isSubGroup": { "alias": "_isSubGroup"; "required": false; }; "_subjectDropdownOptions": { "alias": "_subjectDropdownOptions"; "required": false; }; }, { "conditionGroupChange": "conditionGroupChange"; "groupDeleted": "groupDeleted"; "groupConditionDeleted": "groupConditionDeleted"; "groupConditionUpdated": "groupConditionUpdated"; }, never, never, false, never>;
}

declare class SidePanelAction extends ButtonGridItem {
    value: string;
    text: string;
    icon: string;
    e2e: string;
    constructor(value: string, text: string, icon: string, e2e: string);
}

declare class SidePanelComponent extends BaseTextComponent {
    /**
     * Required: Title Text
     */
    headerTitle: string;
    /**
     * Optional: Show edit button next to title. Will emit an event when clicked.
     */
    showHeaderEditButton: boolean;
    /**
     * Optional: Description text shown below the title. Can be left blank if not needed.
     */
    headerDescription: string;
    /**
     * Required: Date last updated
     */
    headerLastUpdated: Date | null;
    /**
     * Optional: Array of header action buttons to display.
     */
    headerActions: SidePanelAction[];
    /**
     * Optional: Array of badges to display in the header.
     */
    headerBadges: BadgeModel[];
    /**
     * Optional: Array of footer action buttons to display. Max 2 buttons.
     */
    footerActions: SidePanelAction[];
    editHeaderButtonClick: EventEmitter<void>;
    headerActionsClick: EventEmitter<string>;
    footerActionsClick: EventEmitter<string>;
    constructor(textService: TextService);
    onEditHeaderButtonClick(): void;
    onHeaderActionsClick(value: string): void;
    onFooterActionsClick(value: string): void;
    protected getDefaultText(): any;
    static ɵfac: i0.ɵɵFactoryDeclaration<SidePanelComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SidePanelComponent, "ui-management-side-panel", never, { "headerTitle": { "alias": "headerTitle"; "required": false; }; "showHeaderEditButton": { "alias": "showHeaderEditButton"; "required": false; }; "headerDescription": { "alias": "headerDescription"; "required": false; }; "headerLastUpdated": { "alias": "headerLastUpdated"; "required": false; }; "headerActions": { "alias": "headerActions"; "required": false; }; "headerBadges": { "alias": "headerBadges"; "required": false; }; "footerActions": { "alias": "footerActions"; "required": false; }; }, { "editHeaderButtonClick": "editHeaderButtonClick"; "headerActionsClick": "headerActionsClick"; "footerActionsClick": "footerActionsClick"; }, never, ["*"], false, never>;
}

interface StatusTrackerStep {
    title: string;
    icon?: string;
    status?: 'locked' | 'completed' | 'warning' | 'error';
    statusMessage?: string;
    notificationMessage?: string;
    action?: {
        message: string;
        url?: string;
        target?: '_blank' | '_self';
    };
}
interface StatusTrackerStage {
    title: string;
    steps?: StatusTrackerStep[];
}
interface StatusTrackerActionEvent {
    step: StatusTrackerStep;
    stage: StatusTrackerStage;
}
interface StageViewModel extends StatusTrackerStage {
    trackId: string;
    status: StageStatus;
    icon: string;
    stageIcon: IconAttributes;
    hasDetails: boolean;
    isLast: boolean;
}
interface StepViewModel extends StatusTrackerStep {
    trackId: string;
    computedIcon: IconAttributes | null;
    notificationIcon?: {
        icon: string;
        color: string;
    };
    isActive: boolean;
}
interface IconAttributes {
    icon: string;
    ariaLabel?: string;
    backgroundClass: string;
    colorClass: string;
}
declare enum StageStatus {
    Completed = "completed",
    Active = "active",
    Locked = "locked"
}

declare class StatusTrackerComponent implements OnChanges, OnDestroy {
    private el;
    /**
    * Required. Stages to render in the tracker. Maximum of 6 — extras are excluded.
    **/
    stages: StatusTrackerStage[];
    /**
    * Required. This determines which stage will be active, and therefore which will be completed and locked.
    **/
    activeStageIndex: number;
    /**
    * Emits when action button/link is clicked. Includes the stage and step clicked.
    **/
    actionClicked: EventEmitter<StatusTrackerActionEvent>;
    stageViewModels: StageViewModel[];
    constructor(el: ElementRef<HTMLElement>);
    ngOnChanges(): void;
    ngOnDestroy(): void;
    private buildViewModels;
    private computeStatus;
    private computeIcon;
    private boundCloseAll;
    private globalListenersActive;
    private addGlobalListeners;
    private removeGlobalListeners;
    private closeAllDetails;
    stageSummaryClick(event: MouseEvent): void;
    statusTrackerScroll(): void;
    stepActionClick(step: StatusTrackerStep, stage: StatusTrackerStage): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<StatusTrackerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StatusTrackerComponent, "ui-management-status-tracker", never, { "stages": { "alias": "stages"; "required": false; }; "activeStageIndex": { "alias": "activeStageIndex"; "required": false; }; }, { "actionClicked": "actionClicked"; }, never, never, false, never>;
}

interface TreeBadge {
    message: string;
    theme?: BadgeTheme;
    framed?: boolean;
}
/**
 * A node in the tree. A node with no `children` (omitted or empty) renders as a
 * leaf; a node with children renders as an expandable branch.
 */
interface TreeBranch {
    id: string;
    title: string;
    icon?: string;
    children?: TreeBranch[];
    isExpanded?: boolean;
    level?: number;
    badge?: TreeBadge;
}
interface DropInfo {
    targetId: string;
    targetListId: string;
    action: 'before' | 'after';
}

declare class TreeViewComponent {
    /**
     * Required. The tree items to display.
     */
    set listItems(value: TreeBranch[] | null | undefined);
    /**
     * Maximum number of levels permitted in the tree. Root items are level 1.
     */
    levelLimit: number;
    /**
     * Accessible name for the tree, announced by screen readers. Set this to
     * something meaningful for the context the tree is used in.
     */
    ariaLabel: string;
    /**
     * Emits whenever the tree structure changes.
     */
    readonly listItemsChange: EventEmitter<TreeBranch[]>;
    branches: TreeBranch[];
    dragging: boolean;
    dropActionTodo: DropInfo | null;
    /**
     * The branch currently being dragged. Rendered as a copy in the cross-group
     * drop slot so the destination previews the actual row, matching CDK's
     * native placeholder within a group.
     */
    draggedBranch: TreeBranch | null;
    readonly addAction: InlineAction;
    readonly editAction: InlineAction;
    readonly deleteAction: InlineAction;
    readonly actions: InlineAction[];
    readonly actionsWithoutAdd: InlineAction[];
    private sourceListId;
    private dropWasHandled;
    readonly canEnter: (_drag: CdkDrag<TreeBranch>, dropList: CdkDropList<TreeBranch[]>) => boolean;
    startDrag(listId: string, branch: TreeBranch): void;
    dragMoved(moved: CdkDragMove<TreeBranch>): void;
    drop(event: CdkDragDrop<TreeBranch[]>): void;
    endDrag(): void;
    expand(branch: TreeBranch): void;
    private setLevels;
    private canDropBesideTarget;
    /**
     * Returns the number of descendant levels beneath an item.
     *
     * A leaf has child depth 0.
     * A branch with leaf children has child depth 1.
     */
    private getChildDepth;
    private findBranchAtPoint;
    private getChildrenForList;
    private findBranchById;
    private containsBranch;
    private finishDrop;
    private resetDragState;
    static ɵfac: i0.ɵɵFactoryDeclaration<TreeViewComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TreeViewComponent, "ui-management-tree-view", never, { "listItems": { "alias": "listItems"; "required": false; }; "levelLimit": { "alias": "levelLimit"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; }, { "listItemsChange": "listItemsChange"; }, never, never, false, never>;
}

declare class TargetRuleComponent {
    /**
    * Boolean - true if first rule in group
    **/
    isFirst: boolean;
    /**
    * Boolean - true if this is the first rule of a child group
    **/
    isSubGroup: boolean;
    /**
    * Text to display for the current active operator
    **/
    operator: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TargetRuleComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TargetRuleComponent, "ui-management-target-rule", never, { "isFirst": { "alias": "isFirst"; "required": false; }; "isSubGroup": { "alias": "isSubGroup"; "required": false; }; "operator": { "alias": "operator"; "required": false; }; }, {}, never, never, false, never>;
}

declare class StatusTrackerStepsComponent implements OnChanges {
    /**
     * Required. Steps should be passed in from status tracker parent component. Determines the step data to display.
     **/
    steps: StatusTrackerStep[];
    /**
     * Required. Should be passed in from status tracker parent component. Determines the state of each step.
     **/
    status: StageStatus;
    /**
     * Emits when action button/link is clicked. Includes the stage and step clicked.
     **/
    actionClicked: EventEmitter<StatusTrackerStep>;
    stepViewModels: StepViewModel[];
    ngOnChanges(): void;
    private buildStepViewModels;
    private computeStepIcon;
    private buildIconAttributes;
    private computeNotificationIcon;
    actionClick(step: StatusTrackerStep): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<StatusTrackerStepsComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StatusTrackerStepsComponent, "ui-management-status-tracker-steps", never, { "steps": { "alias": "steps"; "required": false; }; "status": { "alias": "status"; "required": false; }; }, { "actionClicked": "actionClicked"; }, never, never, false, never>;
}

declare class UiManagementModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<UiManagementModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<UiManagementModule, [typeof DragAndDropListComponent, typeof HeaderComponent, typeof HtmlEditorComponent, typeof JsonDiffComponent, typeof JsonEditorComponent, typeof MarkdownEditorComponent, typeof PanelListComponent, typeof SearchBarComponent, typeof TargetConditionComponent, typeof TargetingComponent, typeof TargetOperatorComponent, typeof TargetRuleComponent, typeof TreeViewComponent, typeof SidePanelComponent, typeof StatusTrackerComponent, typeof StatusTrackerStepsComponent], [typeof i17.CommonModule, typeof i18.DragDropModule, typeof i19.FormsModule, typeof i20.MonacoEditorModule, typeof i21.NgbModule, typeof i22.QuillModule, typeof i19.ReactiveFormsModule, typeof i23.UiCoreModule, typeof i24.UiFormsModule], [typeof DragAndDropListComponent, typeof HeaderComponent, typeof HtmlEditorComponent, typeof JsonDiffComponent, typeof JsonEditorComponent, typeof MarkdownEditorComponent, typeof PanelListComponent, typeof SearchBarComponent, typeof TargetingComponent, typeof TreeViewComponent, typeof SidePanelComponent, typeof StatusTrackerComponent]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<UiManagementModule>;
}

export { ConditionOperator, ConditionValueType, DragAndDropListComponent, DragAndDropListItem, DragAndDropListResult, HeaderComponent, HtmlEditorAction, HtmlEditorComponent, JsonDiffComponent, JsonEditorComponent, MarkdownEditorComponent, PanelListComponent, PanelListItem, SearchBarComponent, SidePanelAction, SidePanelComponent, StatusTrackerComponent, TargetCondition, TargetConditionGroup, TargetGroupData, TargetGroupOperator, TargetOperatorOption, TargetOption, TargetResult, TargetWorkflowOptions, TargetingComponent, TreeViewComponent, UiManagementModule };
export type { StatusTrackerActionEvent, StatusTrackerStage, StatusTrackerStep };
