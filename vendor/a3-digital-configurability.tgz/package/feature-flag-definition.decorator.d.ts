import { FeatureFlagDefinitionMetadata } from './feature-flag-definition-metadata.js';
export declare function featureFlagDefinition(metadata: FeatureFlagDefinitionMetadata): any;
