export interface ConfigurablePropertiesMetadata {
    [id: string]: ConfigurablePropertyMetadata;
}
export declare enum ValidationType {
    REGEX = "REGEX"
}
export interface PropertyValidator {
    type: string;
    value: any;
    message?: string;
}
export interface ImportSpec {
    group: string;
    export: string;
}
export interface ConfigurablePropertyMetadata {
    name: string;
    type: 'boolean' | 'number' | 'string' | 'json' | 'array';
    default: any;
    description?: string;
    validation?: PropertyValidator;
    exportAs?: string;
    imported?: ImportSpec;
    category?: string;
    order?: number;
    tags?: string[];
    allowedValues?: string[] | number[];
    categoryOrder?: number;
    /**
     * Export-time options that influence how this decorator is handled by the
     * export-service-metadata tool. These options are never written to the output
     * JSON — they are consumed and removed during the export pass.
     */
    _directives?: {
        /**
         * When multiple services are built from the same TypeScript source (e.g. a shared
         * web-server/src producing both a base and an admin metadata file), use this to
         * restrict the decorator to only the named service(s). If omitted, the decorator
         * is included in every metadata file produced from that source.
         *
         * Accepts a single service name string or an array of service name strings.
         * The comparison is made against the service name passed as the third CLI argument
         * to export-service-metadata.
         *
         * @example
         * // Only include in the admin metadata export
         * _directives: { includeIfServiceName: 'a3-web-server-admin' }
         *
         * @example
         * // Include in either the base or the admin export, but not spa exports
         * _directives: { includeIfServiceName: ['a3-web-server', 'a3-web-server-admin'] }
         */
        includeIfServiceName?: string | string[];
    };
}
export declare function configurableProperty(annotation: ConfigurablePropertyMetadata): any;
