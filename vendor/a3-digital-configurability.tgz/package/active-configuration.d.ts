export interface ActiveConfiguration {
    [key: string]: any;
}
