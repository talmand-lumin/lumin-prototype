export declare enum FiType {
    CREDIT_UNION = "Credit Union",
    BANK = "Bank"
}
