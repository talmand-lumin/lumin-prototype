import { FeatureFlag } from './feature-flag.js';
export declare class MetaOverrides {
    featureFlags: FeatureFlag[];
}
