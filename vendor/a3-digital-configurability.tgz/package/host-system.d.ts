export declare enum HostSystem {
    DEMO = "DEMO",
    CORELATION = "CORELATION",
    SYMITAR = "SYMITAR",
    DNA = "DNA",
    MISER = "MISER",
    PHOENIX = "PHOENIX"
}
