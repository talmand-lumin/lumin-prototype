import { ConfigurablePropertyMetadata } from './configurable-property.decorator.js';
export declare function retiredConfigurableProperty(annotation: ConfigurablePropertyMetadata): any;
