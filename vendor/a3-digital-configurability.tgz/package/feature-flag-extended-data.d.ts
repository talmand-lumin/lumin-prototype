export declare class FeatureFlagExtendedData {
    userList?: string[];
}
