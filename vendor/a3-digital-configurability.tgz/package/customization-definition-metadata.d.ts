export interface CustomizationDefinitionMetadata {
    name: string;
    /**
     * A semver string identifying the version of this customization. Increment this when
     * deploying iterative changes so that the admin customizations list reflects which version
     * of the customization is active in each environment.
     */
    version: string;
    /**
     * Controls the order in which customization plugins are registered into the DI container.
     * Plugins are registered in ascending order, and since `register()` uses `rebind()`, the
     * last plugin registered wins. A higher number therefore takes precedence over a lower one.
     *
     * Convention: SDK base bindings use 0 (the default when omitted). Client plugins typically
     * use 10 to override the base. Use 11 or higher to override another client plugin.
     */
    priority?: number;
    /**
     * A human-readable summary of what this customization does. This value is displayed in the
     * admin customizations list for each environment, so it should be clear and meaningful to
     * someone reviewing active customizations in the admin UI.
     */
    description: string;
    /**
     * The organization responsible for this customization. Use "Lumin Digital" for SDK/platform
     * code, or the client name (e.g. "Redwood CU") for client-specific customizations.
     * Individual developer names are acceptable but secondary — prefer the owning org.
     */
    author: string;
    /**
     * Export-time options that influence how this decorator is handled by the
     * export-service-metadata tool. These options are never written to the output
     * JSON — they are consumed and removed during the export pass.
     */
    _directives?: {
        /**
         * When multiple services are built from the same TypeScript source (e.g. a shared
         * web-server/src producing both a base and an admin metadata file), use this to
         * restrict the decorator to only the named service(s). If omitted, the decorator
         * is included in every metadata file produced from that source.
         *
         * Accepts a single service name string or an array of service name strings.
         * The comparison is made against the service name passed as the third CLI argument
         * to export-service-metadata.
         *
         * @example
         * // Only include in the admin metadata export
         * _directives: { includeIfServiceName: 'a3-web-server-admin' }
         *
         * @example
         * // Include in either the base or the admin export, but not spa exports
         * _directives: { includeIfServiceName: ['a3-web-server', 'a3-web-server-admin'] }
         */
        includeIfServiceName?: string | string[];
    };
}
