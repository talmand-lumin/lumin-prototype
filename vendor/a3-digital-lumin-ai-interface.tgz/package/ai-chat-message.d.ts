export declare class AiChatMessage {
    messageId: string;
    message: string;
    sessionId: string;
    timestamp: Date;
    userId: string;
}
