import { EmbeddingProviderConfig } from './embedding-provider-config.js';
export declare class LuminAiEmbeddingRequest {
    config: EmbeddingProviderConfig;
    values: string[];
}
