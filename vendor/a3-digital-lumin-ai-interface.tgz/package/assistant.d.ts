export declare class Assistant {
    id: string;
    createdAt: number;
    description: string;
    instructions: string;
    metadata: any;
    model: string;
    name: string;
    object: string;
    tools: any[];
    responseFormat?: any;
    temperature?: number;
    toolResources?: any;
    constructor(id: string, createdAt: number, description: string, instructions: string, metadata: any, model: string, name: string, object: string, tools: any[], responseFormat?: any, temperature?: number, toolResources?: any);
}
