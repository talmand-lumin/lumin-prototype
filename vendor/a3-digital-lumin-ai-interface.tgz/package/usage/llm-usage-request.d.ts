import { UsageRequest } from './usage-request.js';
import { UsageType } from './usage-type.js';
import { LLMProvider } from '../llm/llm-provider.js';
import { CompletionResultUsage } from '../llm/completion-result-usage.js';
import { ModelType } from '../models/model-type.js';
export declare class LlmUsageRequest extends UsageRequest {
    type: UsageType.LLM;
    provider: LLMProvider;
    modelType: ModelType;
    usage: CompletionResultUsage;
}
