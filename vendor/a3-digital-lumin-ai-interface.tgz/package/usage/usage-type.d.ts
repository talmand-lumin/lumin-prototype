export declare enum UsageType {
    LLM = "LLM",
    VECTOR_STORE = "VECTOR_STORE"
}
