import { UsageRequest } from './usage-request.js';
import { UsageType } from './usage-type.js';
import { EmbeddingProvider } from '../embedding-provider.js';
export declare class VectorStoreUsageRequest extends UsageRequest {
    type: UsageType.VECTOR_STORE;
    provider: EmbeddingProvider;
    totalTokens: number;
    vectorCount: number;
}
