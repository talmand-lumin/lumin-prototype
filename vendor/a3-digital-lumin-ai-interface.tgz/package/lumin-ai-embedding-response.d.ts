import { LuminAiResultCode } from './lumin-ai-result-code.js';
export declare class LuminAiEmbeddingResponse {
    embeddings: number[][];
    resultCode: LuminAiResultCode;
}
