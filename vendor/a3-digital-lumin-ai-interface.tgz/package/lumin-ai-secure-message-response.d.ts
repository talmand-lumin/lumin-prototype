import { LuminAiResultCode } from './lumin-ai-result-code.js';
export declare class LuminAiSecureMessageResponse {
    messages: string[];
    sessionId: string;
    resultCode: LuminAiResultCode;
}
