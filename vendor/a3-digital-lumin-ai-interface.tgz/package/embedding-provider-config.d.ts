import { EmbeddingProvider } from './embedding-provider.js';
export interface EmbeddingProviderConfig {
    provider: EmbeddingProvider;
    modelName?: string;
    providerOptions?: Record<string, any>;
}
