import { AssistantThreadMessage } from './assistant-thread-message.js';
import { LuminAiBaseResponse } from './lumin-ai-base-response.js';
export declare class LuminAiThreadMessagesResponse extends LuminAiBaseResponse {
    threadMessages: AssistantThreadMessage[];
}
