export declare class LuminAiAssistantNavigationItem {
    title: string;
    url: string;
    category: string;
    keywords: string[];
    openInNewTab?: boolean;
}
