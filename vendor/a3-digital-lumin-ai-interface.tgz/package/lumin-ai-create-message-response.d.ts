import { LuminAiBaseResponse } from './lumin-ai-base-response.js';
import { Message } from './message.js';
export declare class LuminAiCreateMessageResponse extends LuminAiBaseResponse {
    message: Message;
}
