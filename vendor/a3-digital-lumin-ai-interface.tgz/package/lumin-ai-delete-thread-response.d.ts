import { LuminAiBaseResponse } from './lumin-ai-base-response.js';
export declare class LuminAiDeleteThreadResponse extends LuminAiBaseResponse {
    id: string;
    object: string;
    deleted: boolean;
}
