import { LuminAiBaseResponse } from './lumin-ai-base-response.js';
import { Button } from './button.js';
export declare class AiChatMessageResponse extends LuminAiBaseResponse {
    messageId: string;
    userId: string;
    sessionId: string;
    message: string;
    loading?: boolean;
    buttons?: Button[];
}
