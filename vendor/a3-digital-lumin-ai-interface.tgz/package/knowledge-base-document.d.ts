export declare class KnowledgeBaseDocument {
    id: number;
    name: string;
    size: number;
    mimeType: string;
    content: string;
    insertDate: Date;
    lastModifiedDate: Date;
}
