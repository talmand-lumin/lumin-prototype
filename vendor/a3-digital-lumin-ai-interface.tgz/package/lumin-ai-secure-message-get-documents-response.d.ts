import { KnowledgeBaseDocument } from './knowledge-base-document.js';
import { LuminAiResultCode } from './lumin-ai-result-code.js';
export declare class LuminAiSecureMessageGetDocumentsResponse {
    documents: KnowledgeBaseDocument[];
    resultCode: LuminAiResultCode;
}
