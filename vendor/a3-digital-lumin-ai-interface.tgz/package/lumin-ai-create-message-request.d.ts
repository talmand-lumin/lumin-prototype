export declare class LuminAiCreateMessageRequest {
    message: string;
    userId: string;
    sessionId: string;
}
