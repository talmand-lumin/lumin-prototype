export interface Button {
    id: string;
    content: string;
    routingUrl: string;
    interpretAsPlaintext: boolean;
}
