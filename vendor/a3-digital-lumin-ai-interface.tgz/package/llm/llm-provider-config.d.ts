import { LLMProvider } from './llm-provider.js';
import { Model } from '../models/model.js';
export interface ProviderConfig {
    provider: LLMProvider;
    model?: Model;
    settings?: {
        temperature?: number;
        maxRetries?: number;
        maxTokens?: number;
        maxOutputTokens?: number;
    };
    stopSequences?: string[];
    providerOptions?: Record<string, Record<string, any>>;
}
