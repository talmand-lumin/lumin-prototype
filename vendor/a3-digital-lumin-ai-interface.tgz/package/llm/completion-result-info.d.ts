import { LLMProvider } from './llm-provider.js';
export declare class CompletionResultInfo {
    modelName: string;
    provider: LLMProvider;
}
