export declare class Thread {
    id: string;
    createdAt: number;
    metadata: any;
    object: string;
    toolResources: any;
    constructor(id: string, createdAt: number, metadata: any, object: string, toolResources: any);
}
