import { LLMProvider } from '../llm/llm-provider.js';
import { ModelType } from './model-type.js';
export declare class Model {
    readonly type: ModelType;
    readonly name: string;
    readonly provider: LLMProvider;
    readonly approvedForPII: boolean;
    readonly calculateCredits: (inputTokens: number, outputTokens: number) => number;
    constructor(type: ModelType, name: string, provider: LLMProvider, approvedForPII: boolean, calculateCredits: (inputTokens: number, outputTokens: number) => number);
}
