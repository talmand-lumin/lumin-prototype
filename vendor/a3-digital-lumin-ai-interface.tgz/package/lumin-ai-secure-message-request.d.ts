export declare class LuminAiSecureMessageRequest {
    message: string;
    userId: string;
    sessionId: string;
}
