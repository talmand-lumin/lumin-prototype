import { GroupQuotaUsageItem } from './group-quota-usage-item.js';
export declare class GroupQuotaDetailResponse {
    groupQuotaId: string;
    quota: number;
    featureSets: GroupQuotaUsageItem[];
}
