import { FeatureSet } from '../llm/feature-set.js';
export declare class CreateGroupQuotaRequest {
    quota: number;
    featureSets: FeatureSet[];
}
