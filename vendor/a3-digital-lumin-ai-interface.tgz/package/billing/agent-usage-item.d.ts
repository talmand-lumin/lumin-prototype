export declare class AgentUsageItem {
    agent: string;
    creditsUsedThisCycle: number;
}
