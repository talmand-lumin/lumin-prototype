import { BaseCriteria } from './base-criteria.js';
import { CriteriaConfig } from './criteria-config.js';
export declare class AtLeastOneLetter extends BaseCriteria {
    constructor(config: CriteriaConfig);
    protected validateCriteria(input: string): boolean;
}
