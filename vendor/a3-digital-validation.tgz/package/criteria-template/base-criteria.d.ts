import { CriteriaConfig } from './criteria-config.js';
import { CriteriaName } from './criteria-name.js';
export declare abstract class BaseCriteria {
    criteriaName: CriteriaName;
    protected abstract validateCriteria(input: string): boolean;
    enabled: boolean;
    order: number;
    constructor(criteriaName: CriteriaName, config: CriteriaConfig);
    validate(input: string): boolean;
    generateValidationFn(): (input: string) => boolean;
    generateTextParams(): any;
}
