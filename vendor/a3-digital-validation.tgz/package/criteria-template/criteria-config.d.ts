export interface CriteriaConfig {
    enabled: boolean;
    order?: number;
    [props: string]: any;
}
