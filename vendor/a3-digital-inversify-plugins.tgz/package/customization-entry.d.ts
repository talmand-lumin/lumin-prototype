import { CustomizationDefinitionMetadata } from '@a3-digital/configurability';
import { Customization } from './customization.js';
export declare class CustomizationEntry {
    metadata: CustomizationDefinitionMetadata;
    instance: Customization;
    priority: number;
    constructor(metadata: CustomizationDefinitionMetadata, instance: Customization, priority: number);
}
