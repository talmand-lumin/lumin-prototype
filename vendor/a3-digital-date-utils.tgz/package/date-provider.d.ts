import { Clock } from './clock.js';
import { MilitaryTime } from './military-time.js';
export declare class DateProvider {
    private clock;
    constructor(clock: Clock);
    getDate(): Date;
    getFIStartOfDay(): Date;
    getDateAtFITimeToday(hours: number, minutes: number): Date;
    getDateAtFITimeStringToday(timeString: string): Date;
    getFIDateString(): string;
    getFIDateTimeString(): string;
    getFIDateFormatString(format: string): string;
    getLocalDateString(timeZone: string): string;
    getLocalDateTimeString(timeZone: string): string;
    isPastTodaysCutOff(cutOffTime: MilitaryTime, cutOffTimeZone: string): boolean;
    getTodaysCutOffTime(cutOffTime: MilitaryTime, cutOffTimeZone: string): Date;
    isPastTodaysCutOffInFITimeZone(cutOffTime: MilitaryTime): boolean;
    getTodaysCutOffTimeForFITimeZone(cutOffTime: MilitaryTime): Date;
    isPastTodaysCutoffForOtherTimeZone(cutOffTime: MilitaryTime, cutOffTimeZone: string): boolean;
    convertCutoffTimeToFITimeZoneForToday(cutoffTimeZone: string, cutOffTime: MilitaryTime): MilitaryTime;
    isInFITimeWindow(timeRange: string): boolean;
    isInLocalTimeWindow(timeRange: string, timeZone: string): boolean;
}
