import { MonthDayYear } from './month-day-year.js';
export declare class CalendarDate {
    day: number;
    month: number;
    year: number;
    constructor(data?: {
        month: number;
        day: number;
        year: number;
    });
    static fromDate(date: Date): CalendarDate;
    setDate(date: Date): void;
    toDate(): Date;
    toMonthDayYear(): MonthDayYear;
    toDateString(): string;
    add(delta: number, units: string): void;
}
