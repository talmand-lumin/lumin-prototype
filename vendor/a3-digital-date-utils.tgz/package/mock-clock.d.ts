import { Clock } from './clock.js';
export declare class MockClock extends Clock {
    private systemTime;
    constructor(systemTime: Date);
    now(): Date;
    setTime(time: Date): void;
}
