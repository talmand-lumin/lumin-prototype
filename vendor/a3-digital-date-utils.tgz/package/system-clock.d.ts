import { Clock } from './clock.js';
export declare class SystemClock extends Clock {
    now(): Date;
}
