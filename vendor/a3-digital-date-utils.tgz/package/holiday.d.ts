export declare class Holiday {
    name: string;
    date: string;
}
