export declare class MonthDayYear {
    day: number;
    month: number;
    year: number;
    timeZone: string;
    constructor(month: any, day: any, year: any, timeZone: any);
    static fromFIDate(date: Date): MonthDayYear;
    static fromLocalDate(date: Date, timeZone: string): MonthDayYear;
    toDate(): Date;
    toDateString(): string;
}
